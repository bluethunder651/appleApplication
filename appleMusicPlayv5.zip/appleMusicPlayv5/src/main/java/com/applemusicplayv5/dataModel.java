package com.applemusicplayv5;

import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;

public class dataModel {

    private final ObservableList<dataObject> selectedSongsTrackList = FXCollections.observableArrayList(dataObject -> new Observable[]{
            dataObject.artistProperty(), dataObject.buildVersionProperty(), dataObject.endReasonProperty(), dataObject.eventStartProperty(), dataObject.eventTypeProperty(), dataObject.featureProperty(), dataObject.mediaTypeProperty(), dataObject.titleProperty(), dataObject.endPosProperty(), dataObject.mediaDurationProperty(), dataObject.startPosProperty(), dataObject.playDurationProperty(), dataObject.composerProperty(), dataObject.albumProperty(), dataObject.albumArtistProperty(), dataObject.genreProperty(), dataObject.dALProperty(), dataObject.lastPlayedProperty(), dataObject.lastSkipProperty(), dataObject.aFEProperty(), dataObject.releaseDateProperty(), dataObject.copyrightProperty(), dataObject.yearProperty(), dataObject.albumNumberProperty(), dataObject.albumCountProperty(), dataObject.bpmProperty(), dataObject.playCountProperty(), dataObject.skipCountProperty(), dataObject.offlineProperty(), dataObject.compilationProperty()
    });

    private final ObservableList<frequencyList> firstLayerArtistFrequencyList = FXCollections.observableArrayList(frequencyList -> new Observable[]{
            frequencyList.nameProperty(), frequencyList.frequencyProperty()
    });

    private final ObservableList<frequencyList> firstLayerSongFrequencyList = FXCollections.observableArrayList(frequencyList -> new Observable[]{
        frequencyList.nameProperty(), frequencyList.frequencyProperty()
    });

    private final ObservableList<frequencyList> secondLayerFrequencyList = FXCollections.observableArrayList(frequencyList -> new Observable[]{
            frequencyList.nameProperty(), frequencyList.frequencyProperty()
    });

    private final ObservableList<trackInfoColumn> trackInfoColumnList = FXCollections.observableArrayList(trackInfoColumn -> new Observable[]{
            trackInfoColumn.fieldProperty(), trackInfoColumn.outputProperty()
    });
    private final ObservableList<frequencyList> albumFrequencyList = FXCollections.observableArrayList(frequencyList -> new Observable[]{
            frequencyList.nameProperty(), frequencyList.frequencyProperty()
    });

    private final ObservableList<frequencyList> songsFromAlbumFrequencyList = FXCollections.observableArrayList(frequencyList -> new Observable[]{
            frequencyList.nameProperty(), frequencyList.frequencyProperty()
    });

    private final ObservableList<frequencyList> genreFrequencyList = FXCollections.observableArrayList(frequencyList -> new Observable[]{
            frequencyList.nameProperty(), frequencyList.frequencyProperty()
    });

    private final ObservableList<frequencyList> songsFromGenreFrequencyList = FXCollections.observableArrayList(frequencyList -> new Observable[]{
            frequencyList.nameProperty(), frequencyList.frequencyProperty()
    });
    private final ObservableList<dataObject> infoList = FXCollections.observableArrayList(dataObject -> new Observable[]{
            dataObject.artistProperty(), dataObject.buildVersionProperty(), dataObject.endReasonProperty(), dataObject.eventStartProperty(), dataObject.eventTypeProperty(), dataObject.featureProperty(), dataObject.mediaTypeProperty(), dataObject.titleProperty(), dataObject.endPosProperty(), dataObject.mediaDurationProperty(), dataObject.startPosProperty(), dataObject.playDurationProperty(), dataObject.composerProperty(), dataObject.albumProperty(), dataObject.albumArtistProperty(), dataObject.genreProperty(), dataObject.dALProperty(), dataObject.lastPlayedProperty(), dataObject.lastSkipProperty(), dataObject.aFEProperty(), dataObject.releaseDateProperty(), dataObject.copyrightProperty(), dataObject.yearProperty(), dataObject.albumNumberProperty(), dataObject.albumCountProperty(), dataObject.bpmProperty(), dataObject.playCountProperty(), dataObject.skipCountProperty(), dataObject.offlineProperty(), dataObject.compilationProperty()
    });
    private final ObservableList<frequencyList> endReasonFrequencyList = FXCollections.observableArrayList(frequencyList -> new Observable[]{
            frequencyList.nameProperty(), frequencyList.frequencyProperty()
    });
    private final ObservableList<playTimeObject> totalPlayTime = FXCollections.observableArrayList(playTimeObject -> new Observable[]{
            playTimeObject.nameProperty(), playTimeObject.playTimeProperty()
    });
    private final ObservableList<playTimeObject> averagePlayTimeList = FXCollections.observableArrayList(playTimeObject -> new Observable[]{
            playTimeObject.nameProperty(), playTimeObject.playTimeProperty()
    });
    private final ObservableList<playTimeObject> releaseDateList = FXCollections.observableArrayList(playTimeObject -> new Observable[]{
            playTimeObject.nameProperty(), playTimeObject.playTimeProperty()
    });

    private final SimpleStringProperty csvFile = new SimpleStringProperty(null);

    private final SimpleStringProperty trackJson = new SimpleStringProperty(null);

    private final XYChart.Series dayFrequencyBarChart = new XYChart.Series<>();

    private final XYChart.Series monthFrequencyBarChart = new XYChart.Series<>();

    private final ObservableList<XYChart.Series> yearAndMonthFrequencyBarChart = FXCollections.observableArrayList();

    public final XYChart.Series yearFrequencyBarChart = new XYChart.Series();

    private final ObservableList<PieChart.Data> artistPieChart = FXCollections.observableArrayList();

    private final ObservableList<PieChart.Data> songPieChart = FXCollections.observableArrayList();

    private final ObservableList<PieChart.Data> genrePieChart = FXCollections.observableArrayList();

    private final ObservableList<PieChart.Data> albumPieChart = FXCollections.observableArrayList();

    private final ObservableList<PieChart.Data> endReasonPieChart = FXCollections.observableArrayList();

    private final ObservableList<PieChart.Data> averageTimePieChart = FXCollections.observableArrayList();

    private final ObservableList<PieChart.Data> totalTimePieChart = FXCollections.observableArrayList();

    private final XYChart.Series timeFrequencyBarChart = new XYChart.Series<>();

    private final ObjectProperty<frequencyList> currentFirstLayerSongFrequencyData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<dataObject> currentSelectedSongTrackData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<dataCreator> currentTrackData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<frequencyList> currentEndReasonListData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<frequencyList> currentFirstLayerArtistFrequencyData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<frequencyList> currentSecondLayerFrequencyData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<trackInfoColumn> currentTrackInfoColumnData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<PieChart.Data> currentArtistPieChartData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<PieChart.Data> currentSongPieChartData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<PieChart.Data> currentGenrePieChartData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<PieChart.Data> currentAlbumPieChartData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<PieChart.Data> currentEndReasonPieChartData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<PieChart.Data> currentAverageTimePieChartData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<PieChart.Data> currentTotalTimePieChartData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<XYChart.Series> currentYearFrequencyBarChartData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<XYChart.Series> currentMonthFrequencyBarChartData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<XYChart.Series> currentYearAndMonthFrequencyBarChartData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<XYChart.Series> currentTimeFrequencyBarChartData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<frequencyList> currentAlbumFrequencyData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<frequencyList> currentSongFromAlbumFrequencyData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<frequencyList> headerFromAlbum = new SimpleObjectProperty<>(null);

    private final ObjectProperty<frequencyList> currentGenreFrequencyData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<frequencyList> currentSongFromGenreFrequencyData = new SimpleObjectProperty<>(null);

    private final ObjectProperty<dataObject> currentInfoListData = new SimpleObjectProperty<>(null);

    private final SimpleBooleanProperty onlyPlayEnd = new SimpleBooleanProperty(false);

    public ObjectProperty<playTimeObject> currentTotalPlayTimeList = new SimpleObjectProperty<>(null);

    public ObjectProperty<playTimeObject> currentAveragePlayTimeListData = new SimpleObjectProperty<>(null);

    public ObjectProperty<playTimeObject> currentReleaseDateListData = new SimpleObjectProperty<>(null);

    public ObservableList<PieChart.Data> getAverageTimePieChart() {
        return averageTimePieChart;
    }

    public ObservableList<PieChart.Data> getTotalTimePieChart() {
        return totalTimePieChart;
    }

    public PieChart.Data getCurrentAverageTimePieChartData() {
        return currentAverageTimePieChartData.get();
    }

    public ObjectProperty<PieChart.Data> currentAverageTimePieChartDataProperty() {
        return currentAverageTimePieChartData;
    }

    public void setCurrentAverageTimePieChartData(PieChart.Data currentAverageTimePieChartData) {
        this.currentAverageTimePieChartData.set(currentAverageTimePieChartData);
    }

    public PieChart.Data getCurrentTotalTimePieChartData() {
        return currentTotalTimePieChartData.get();
    }

    public ObjectProperty<PieChart.Data> currentTotalTimePieChartDataProperty() {
        return currentTotalTimePieChartData;
    }

    public void setCurrentTotalTimePieChartData(PieChart.Data currentTotalTimePieChartData) {
        this.currentTotalTimePieChartData.set(currentTotalTimePieChartData);
    }

    public ObservableList<playTimeObject> getReleaseDateList() {
        return releaseDateList;
    }

    public playTimeObject getCurrentReleaseDateListData() {
        return currentReleaseDateListData.get();
    }

    public ObjectProperty<playTimeObject> currentReleaseDateListDataProperty() {
        return currentReleaseDateListData;
    }

    public void setCurrentReleaseDateListData(playTimeObject currentReleaseDateListData) {
        this.currentReleaseDateListData.set(currentReleaseDateListData);
    }

    public XYChart.Series getYearFrequencyBarChart() {
        return yearFrequencyBarChart;
    }

    public ObservableList<playTimeObject> getAveragePlayTimeList() {
        return averagePlayTimeList;
    }

    public playTimeObject getCurrentAveragePlayTimeListData() {
        return currentAveragePlayTimeListData.get();
    }

    public ObjectProperty<playTimeObject> currentAveragePlayTimeListDataProperty() {
        return currentAveragePlayTimeListData;
    }

    public void setCurrentAveragePlayTimeListData(playTimeObject currentAveragePlayTimeListData) {
        this.currentAveragePlayTimeListData.set(currentAveragePlayTimeListData);
    }

    public ObservableList<playTimeObject> getTotalPlayTime() {
        return totalPlayTime;
    }

    public playTimeObject getCurrentTotalPlayTimeList() {
        return currentTotalPlayTimeList.get();
    }

    public ObjectProperty<playTimeObject> currentTotalPlayTimeListProperty() {
        return currentTotalPlayTimeList;
    }

    public void setCurrentTotalPlayTimeList(playTimeObject currentTotalPlayTimeList) {
        this.currentTotalPlayTimeList.set(currentTotalPlayTimeList);
    }

    public ObservableList<frequencyList> getEndReasonFrequencyList() {
        return endReasonFrequencyList;
    }

    public frequencyList getCurrentEndReasonListData() {
        return currentEndReasonListData.get();
    }

    public ObjectProperty<frequencyList> currentEndReasonListDataProperty() {
        return currentEndReasonListData;
    }

    public void setCurrentEndReasonListData(frequencyList currentEndReasonListData) {
        this.currentEndReasonListData.set(currentEndReasonListData);
    }

    public ObservableList<PieChart.Data> getEndReasonPieChart() {
        return endReasonPieChart;
    }

    public PieChart.Data getCurrentEndReasonPieChartData() {
        return currentEndReasonPieChartData.get();
    }

    public ObjectProperty<PieChart.Data> currentEndReasonPieChartDataProperty() {
        return currentEndReasonPieChartData;
    }

    public void setCurrentEndReasonPieChartData(PieChart.Data currentEndReasonPieChartData) {
        this.currentEndReasonPieChartData.set(currentEndReasonPieChartData);
    }

    public boolean isOnlyPlayEnd() {
        return onlyPlayEnd.get();
    }

    public SimpleBooleanProperty onlyPlayEndProperty() {
        return onlyPlayEnd;
    }

    public void setOnlyPlayEnd(boolean onlyPlayEnd) {
        this.onlyPlayEnd.set(onlyPlayEnd);
    }

    public ObservableList<PieChart.Data> getAlbumPieChart() {
        return albumPieChart;
    }

    public PieChart.Data getCurrentAlbumPieChartData() {
        return currentAlbumPieChartData.get();
    }

    public ObjectProperty<PieChart.Data> currentAlbumPieChartDataProperty() {
        return currentAlbumPieChartData;
    }

    public void setCurrentAlbumPieChartData(PieChart.Data currentAlbumPieChartData) {
        this.currentAlbumPieChartData.set(currentAlbumPieChartData);
    }

    public ObservableList<PieChart.Data> getGenrePieChart() {
        return genrePieChart;
    }

    public PieChart.Data getCurrentGenrePieChartData() {
        return currentGenrePieChartData.get();
    }

    public ObjectProperty<PieChart.Data> currentGenrePieChartDataProperty() {
        return currentGenrePieChartData;
    }

    public void setCurrentGenrePieChartData(PieChart.Data currentGenrePieChartData) {
        this.currentGenrePieChartData.set(currentGenrePieChartData);
    }

    public String getCsvFile() {
        return csvFile.get();
    }

    public SimpleStringProperty csvFileProperty() {
        return csvFile;
    }

    public void setCsvFile(String csvFile) {
        this.csvFile.set(csvFile);
    }

    public String getTrackJson() {
        return trackJson.get();
    }

    public SimpleStringProperty trackJsonProperty() {
        return trackJson;
    }

    public void setTrackJson(String trackJson) {
        this.trackJson.set(trackJson);
    }

    public XYChart.Series getDayFrequencyBarChart() {
        return dayFrequencyBarChart;
    }

    public ObservableList<dataObject> getInfoList() {
        return infoList;
    }

    public dataObject getCurrentInfoListData() {
        return currentInfoListData.get();
    }

    public ObjectProperty<dataObject> currentInfoListDataProperty() {
        return currentInfoListData;
    }

    public void setCurrentInfoListData(dataObject currentInfoListData) {
        this.currentInfoListData.set(currentInfoListData);
    }

    private final StringProperty header = new SimpleStringProperty(null);

    public String getHeader() {
        return header.get();
    }

    public StringProperty headerProperty() {
        return header;
    }

    public void setHeader(String header) {
        this.header.set(header);
    }

    public ObservableList<frequencyList> getSongsFromGenreFrequencyList() {
        return songsFromGenreFrequencyList;
    }

    public frequencyList getCurrentSongFromGenreFrequencyData() {
        return currentSongFromGenreFrequencyData.get();
    }

    public ObjectProperty<frequencyList> currentSongFromGenreFrequencyDataProperty() {
        return currentSongFromGenreFrequencyData;
    }

    public void setCurrentSongFromGenreFrequencyData(frequencyList currentSongFromGenreFrequencyData) {
        this.currentSongFromGenreFrequencyData.set(currentSongFromGenreFrequencyData);
    }

    public ObservableList<frequencyList> getGenreFrequencyList() {
        return genreFrequencyList;
    }

    public frequencyList getCurrentGenreFrequencyData() {
        return currentGenreFrequencyData.get();
    }

    public ObjectProperty<frequencyList> currentGenreFrequencyDataProperty() {
        return currentGenreFrequencyData;
    }

    public void setCurrentGenreFrequencyData(frequencyList currentGenreFrequencyData) {
        this.currentGenreFrequencyData.set(currentGenreFrequencyData);
    }

    public frequencyList getHeaderFromAlbum() {
        return headerFromAlbum.get();
    }

    public ObjectProperty<frequencyList> headerFromAlbumProperty() {
        return headerFromAlbum;
    }

    public void setHeaderFromAlbum(frequencyList headerFromAlbum) {
        this.headerFromAlbum.set(headerFromAlbum);
    }

    public ObservableList<frequencyList> getSongsFromAlbumFrequencyList() {
        return songsFromAlbumFrequencyList;
    }

    public frequencyList getCurrentSongFromAlbumFrequencyData() {
        return currentSongFromAlbumFrequencyData.get();
    }


    public ObjectProperty<frequencyList> currentSongFromAlbumFrequencyDataProperty() {
        return currentSongFromAlbumFrequencyData;
    }

    public void setCurrentSongFromAlbumFrequencyData(frequencyList currentSongFromAlbumFrequencyData) {
        this.currentSongFromAlbumFrequencyData.set(currentSongFromAlbumFrequencyData);
    }

    public ObservableList<frequencyList> getAlbumFrequencyList() {
        return albumFrequencyList;
    }

    public frequencyList getCurrentAlbumFrequencyData() {
        return currentAlbumFrequencyData.get();
    }

    public ObjectProperty<frequencyList> currentAlbumFrequencyDataProperty() {
        return currentAlbumFrequencyData;
    }

    public void setCurrentAlbumFrequencyData(frequencyList currentAlbumFrequencyData) {
        this.currentAlbumFrequencyData.set(currentAlbumFrequencyData);
    }

    public XYChart.Series getTimeFrequencyBarChart() {
        return timeFrequencyBarChart;
    }

    public XYChart.Series getCurrentTimeFrequencyBarChartData() {
        return currentTimeFrequencyBarChartData.get();
    }

    public ObjectProperty<XYChart.Series> currentTimeFrequencyBarChartDataProperty() {
        return currentTimeFrequencyBarChartData;
    }

    public void setCurrentTimeFrequencyBarChartData(XYChart.Series currentTimeFrequencyBarChartData) {
        this.currentTimeFrequencyBarChartData.set(currentTimeFrequencyBarChartData);
    }

    public ObservableList<frequencyList> getFirstLayerArtistFrequencyList() {
        return firstLayerArtistFrequencyList;
    }

    public ObservableList<XYChart.Series> getYearAndMonthFrequencyBarChart() {
        return yearAndMonthFrequencyBarChart;
    }

    public XYChart.Series getCurrentYearAndMonthFrequencyBarChartData() {
        return currentYearAndMonthFrequencyBarChartData.get();
    }

    public ObjectProperty<XYChart.Series> currentYearAndMonthFrequencyBarChartDataProperty() {
        return currentYearAndMonthFrequencyBarChartData;
    }

    public void setCurrentYearAndMonthFrequencyBarChartData(XYChart.Series currentYearAndMonthFrequencyBarChartData) {
        this.currentYearAndMonthFrequencyBarChartData.set(currentYearAndMonthFrequencyBarChartData);
    }

    public XYChart.Series getMonthFrequencyBarChart() {
        return monthFrequencyBarChart;
    }

    public XYChart.Series getCurrentMonthFrequencyBarChartData() {
        return currentMonthFrequencyBarChartData.get();
    }

    public ObjectProperty<XYChart.Series> currentMonthFrequencyBarChartDataProperty() {
        return currentMonthFrequencyBarChartData;
    }

    public void setCurrentMonthFrequencyBarChartData(XYChart.Series currentMonthFrequencyBarChartData) {
        this.currentMonthFrequencyBarChartData.set(currentMonthFrequencyBarChartData);
    }

    public frequencyList getCurrentFirstLayerArtistFrequencyData() {
        return currentFirstLayerArtistFrequencyData.get();
    }

    public ObjectProperty<frequencyList> currentFirstLayerArtistFrequencyDataProperty() {
        return currentFirstLayerArtistFrequencyData;
    }

    public XYChart.Series getCurrentYearFrequencyBarChartData() {
        return currentYearFrequencyBarChartData.get();
    }

    public ObjectProperty<XYChart.Series> currentYearFrequencyBarChartDataProperty() {
        return currentYearFrequencyBarChartData;
    }

    public void setCurrentYearFrequencyBarChartData(XYChart.Series currentYearFrequencyBarChartData) {
        this.currentYearFrequencyBarChartData.set(currentYearFrequencyBarChartData);
    }

    public ObservableList<PieChart.Data> getSongPieChart() {
        return songPieChart;
    }

    public PieChart.Data getCurrentSongPieChartData() {
        return currentSongPieChartData.get();
    }

    public ObjectProperty<PieChart.Data> currentSongPieChartDataProperty() {
        return currentSongPieChartData;
    }

    public void setCurrentSongPieChartData(PieChart.Data currentSongPieChartData) {
        this.currentSongPieChartData.set(currentSongPieChartData);
    }

    public ObservableList<PieChart.Data> getArtistPieChart() {
        return artistPieChart;
    }

    public PieChart.Data getCurrentArtistPieChartData() {
        return currentArtistPieChartData.get();
    }

    public ObjectProperty<PieChart.Data> currentArtistPieChartDataProperty() {
        return currentArtistPieChartData;
    }

    public void setCurrentArtistPieChartData(PieChart.Data currentArtistPieChartData) {
        this.currentArtistPieChartData.set(currentArtistPieChartData);
    }

    public ObservableList<frequencyList> getFirstLayerSongFrequencyList() {
        return firstLayerSongFrequencyList;
    }

    public frequencyList getCurrentFirstLayerSongFrequencyData() {
        return currentFirstLayerSongFrequencyData.get();
    }

    public ObjectProperty<frequencyList> currentFirstLayerSongFrequencyDataProperty() {
        return currentFirstLayerSongFrequencyData;
    }

    public void setCurrentFirstLayerSongFrequencyData(frequencyList currentFirstLayerSongFrequencyData) {
        this.currentFirstLayerSongFrequencyData.set(currentFirstLayerSongFrequencyData);
    }

    public ObservableList<trackInfoColumn> getTrackInfoColumnList() {
        return trackInfoColumnList;
    }

    public trackInfoColumn getCurrentTrackInfoColumnData() {
        return currentTrackInfoColumnData.get();
    }

    public ObjectProperty<trackInfoColumn> currentTrackInfoColumnDataProperty() {
        return currentTrackInfoColumnData;
    }

    public void setCurrentTrackInfoColumnData(trackInfoColumn currentTrackInfoColumnData) {
        this.currentTrackInfoColumnData.set(currentTrackInfoColumnData);
    }

    public ObservableList<dataObject> getSelectedSongsTrackList() {
        return selectedSongsTrackList;
    }

    public dataObject getCurrentSelectedSongTrackData() {
        return currentSelectedSongTrackData.get();
    }

    public ObjectProperty<dataObject> getCurrentSelectedSongTrackDataProperty(){
        return currentSelectedSongTrackData;
    }

    public ObjectProperty<dataObject> currentSelectedSongTrackDataProperty() {
        return currentSelectedSongTrackData;
    }

    public void setCurrentSelectedSongTrackData(dataObject currentSelectedSongTrackData) {
        this.currentSelectedSongTrackData.set(currentSelectedSongTrackData);
    }

    public ObservableList<frequencyList> getSecondLayerFrequencyList() {
        return secondLayerFrequencyList;
    }

    public frequencyList getCurrentSecondLayerFrequencyData() {
        return currentSecondLayerFrequencyData.get();
    }

    public ObjectProperty<frequencyList> getCurrentSecondLayerFrequencyDataProperty(){
        return currentSecondLayerFrequencyData;
    }

    public ObjectProperty<frequencyList> currentSecondLayerFrequencyDataProperty() {
        return currentSecondLayerFrequencyData;
    }

    public void setCurrentSecondLayerFrequencyData(frequencyList currentSecondLayerFrequencyData) {
        this.currentSecondLayerFrequencyData.set(currentSecondLayerFrequencyData);
    }

    public frequencyList getCurrentFirstLayerFrequencyArtistData() {
        return currentFirstLayerArtistFrequencyData.get();
    }

    public ObjectProperty<frequencyList> getCurrentFirstLayerFrequencyArtistDataProperty(){
        return currentFirstLayerArtistFrequencyData;
    }

    public void setCurrentFirstLayerArtistFrequencyData (frequencyList currentFrequencyData) {
        this.currentFirstLayerArtistFrequencyData.set(currentFrequencyData);
    }

    public dataCreator getCurrentTrackData() {
        return currentTrackData.get();
    }

    public ObjectProperty<dataCreator> getCurrentTrackDataProperty(){
        return currentTrackData;
    }

    public ObjectProperty<dataCreator> currentTrackDataProperty() {
        return currentTrackData;
    }

    public void setCurrentTrackData(dataCreator currentTrackData) {
        this.currentTrackData.set(currentTrackData);
    }


    public void loadBeginningData(){
        System.out.println("Loading Apple Music Play Activity.csv");
        loadInfoList(getTrackJson(),getCsvFile(), isOnlyPlayEnd());
        System.out.println("Loaded Apple Music Play Activity.csv");
        System.out.println("Loading Artists List");
        loadFirstLayerArtistFrequencyList();
        System.out.println("Loaded Artists List");
        System.out.println("Loading Songs List");
        loadFirstLayerSongFrequencyList();
        System.out.println("Loaded Songs List");
        System.out.println("Loading Artist Pie Chart");
        loadArtistPieChartDataList(15);
        System.out.println("Loaded Artist Pie Chart");
        System.out.println("Loading Song Pie Chart");
        loadSongPieChartDataList(15);
        System.out.println("Loaded Song Pie Chart");
        System.out.println("Loading Albums List");
        loadAlbumFrequencyList();
        System.out.println("Loaded Albums List");
        System.out.println("Loading Genre List");
        loadGenreFrequencyList();
        System.out.println("Loaded Genre List");
        System.out.println("Loading End Reason List");
        loadEndReasonFrequencyList();
        System.out.println("Loaded End Reason List");
        System.out.println("Loading Play Time List");
        loadPlayTimeFrequencyList();
        System.out.println("Loaded Play Time List");
        System.out.println("Loading Average Play Time List");
        loadAveragePlayTimeList();
        System.out.println("Loaded Average Play Time List");
        System.out.println("Loading Release Date List");
        loadReleaseDateFrequencyList();
        System.out.println("Loaded Release Date List");
    }

    public void loadFirstLayerArtistFrequencyList(){
        firstLayerArtistFrequencyList.setAll(analyze.firstLayerFrequencyMaker(infoList, homeController.ids.artists.getValue()));
    }
    public void loadFirstLayerSongFrequencyList(){
        firstLayerSongFrequencyList.setAll(analyze.firstLayerFrequencyMaker(infoList, homeController.ids.songs.getValue()));
    }
    public void loadSecondLayerFrequencyList(){
        secondLayerFrequencyList.setAll(analyze.secondLayerFrequencyMaker(infoList, homeController.ids.artists.getValue(), getCurrentFirstLayerFrequencyArtistData().getName()));
    }
    public void loadEndReasonFrequencyList(){
        endReasonFrequencyList.setAll(analyze.firstLayerFrequencyMaker(infoList, homeController.ids.endReason.getValue()));
    }
    public void loadReleaseDateFrequencyList(){
        releaseDateList.setAll(analyze.releaseDateAnalyzer(infoList));
    }

    public void loadSelectedSongTrackList(){
        selectedSongsTrackList.setAll(analyze.selectedSongsTrackList(infoList, getCurrentSecondLayerFrequencyData().getName(), getCurrentFirstLayerFrequencyArtistData().getName(), homeController.ids.artists.getValue()));
    }
    public void loadSelectedSongTrackListFromSongMenu(){
        selectedSongsTrackList.setAll(analyze.selectedSongsTrackList(infoList, getCurrentFirstLayerFrequencyArtistData().getName(), homeController.ids.songs.getValue()));
    }
    public void loadSelectedSongTrackListFromAlbumMenu(){
        selectedSongsTrackList.setAll(analyze.selectedSongsTrackList(infoList, getCurrentSongFromAlbumFrequencyData().getName(), getCurrentAlbumFrequencyData().getName().substring(0,getCurrentAlbumFrequencyData().getName().indexOf(", by ")), homeController.ids.albums.getValue()));
    }
    public void loadSelectedSongTrackListFromGenre(){
        selectedSongsTrackList.setAll(analyze.selectedSongsTrackList(infoList,getCurrentSongFromGenreFrequencyData().getName(), homeController.ids.genre.getValue()));
    }
    public void loadSelectedSongTrackListFromPlayTime(){
        selectedSongsTrackList.setAll(analyze.selectedSongsTrackList(infoList, getCurrentTotalPlayTimeList().getName(), homeController.ids.playTime.getValue()));
    }
    public void loadSelectedSongTrackListFromAverageTime(){
        selectedSongsTrackList.setAll(analyze.selectedSongsTrackList(infoList, getCurrentAveragePlayTimeListData().getName(), homeController.ids.averageTime.getValue()));
    }
    public void loadSelectedSongTrackListFromReleaseDate(){
        selectedSongsTrackList.setAll(analyze.selectedSongsTrackList(infoList, getCurrentReleaseDateListData().getName(), homeController.ids.releaseDate.getValue()));
    }
    public void loadTrackInfoColumnList(){
        trackInfoColumnList.setAll(analyze.trackInfoToColumn(infoList, getCurrentSecondLayerFrequencyData().getName(), getCurrentFirstLayerFrequencyArtistData().getName(), homeController.ids.artists.getValue()));
    }
    public void loadTrackInfoColumnListFromSongMenu(){
        trackInfoColumnList.setAll(analyze.trackInfoToColumn(infoList, getCurrentFirstLayerFrequencyArtistData().getName()));
    }
    public void loadTrackInfoColumnListFromAlbumMenu(){
        trackInfoColumnList.setAll(analyze.trackInfoToColumn(infoList, getCurrentSongFromAlbumFrequencyData().getName(), getCurrentAlbumFrequencyData().getName().substring(0, getCurrentAlbumFrequencyData().getName().indexOf(", by ")), homeController.ids.albums.getValue()));
    }
    public void loadTrackInfoColumnListFromGenre(){
        trackInfoColumnList.setAll(analyze.trackInfoToColumn(infoList, getCurrentSongFromGenreFrequencyData().getName()));
    }
    public void loadTrackInfoColumnListFromPlayTime(){
        trackInfoColumnList.setAll(analyze.trackInfoToColumn(infoList, getCurrentTotalPlayTimeList().getName()));
    }
    public void loadTrackInfoColumnListFromAverageTime(){
        trackInfoColumnList.setAll(analyze.trackInfoToColumn(infoList, getCurrentAveragePlayTimeListData().getName()));
    }
    public void loadTrackInfoColumnListFromReleaseDate(){
        trackInfoColumnList.setAll(analyze.trackInfoToColumn(infoList, getCurrentReleaseDateListData().getName()));
    }
    public void loadArtistPieChartDataList(int count){
        artistPieChart.setAll(analyze.pieChartDataMaker(infoList, homeController.ids.artists.getValue(), count));
    }
    public void loadSongPieChartDataList(int count){
        songPieChart.setAll(analyze.pieChartDataMaker(infoList, homeController.ids.songs.getValue(), count));
    }
    public void loadGenrePieChartDataList(int count){
        genrePieChart.setAll(analyze.pieChartDataMaker(infoList, homeController.ids.genre.getValue(), count));
    }
    public void loadAlbumPieChartDataList(int count){
        albumPieChart.setAll(analyze.pieChartDataMaker(infoList, homeController.ids.albums.getValue(), count));
    }
    public void loadEndReasonPieChartDataList(int count){
        endReasonPieChart.setAll(analyze.pieChartDataMaker(infoList, homeController.ids.endReason.getValue(), count));
    }
    public void loadAverageTimePieChartDataList(int count){
        averageTimePieChart.setAll(analyze.pieChartDataFromPlayTimeObject(getAveragePlayTimeList(), count));
    }
    public void loadTotalTimePieChartDataList(int count){
        totalTimePieChart.setAll(analyze.pieChartDataFromPlayTimeObject(totalPlayTime, count));
    }
    public void loadMonthFrequencyList(int id){
        monthFrequencyBarChart.setData(analyze.monthFrequency(infoList, id));
    }
    public void loadDayFrequencyList(int id){
        dayFrequencyBarChart.setData(analyze.dayFrequency(infoList, id));
    }
    public void loadYearAndMonthFrequencyList(){
        yearAndMonthFrequencyBarChart.setAll(analyze.yearAndMonth(infoList));
    }
    public void loadTimeFrequencyList(){
        timeFrequencyBarChart.setData(analyze.timeFrequency(infoList));
    }
    public void loadYearFrequencyList(){
        yearFrequencyBarChart.setData(analyze.yearFrequency(getReleaseDateList()));
    }

    public void loadDayFromFrequencyList(int id){
        dayFrequencyBarChart.setData(analyze.dayFrequency(getSelectedSongsTrackList(), id));
    }
    public void loadDayFromObjectList(){
        dayFrequencyBarChart.setData(analyze.dayFrequencyFromPlayTimeObject(getReleaseDateList()));
    }
    public void loadMonthFromObjectList(){
        monthFrequencyBarChart.setData(analyze.monthFrequencyFromPlayTimeObject(getReleaseDateList()));
    }

    public void loadMonthFromSongFrequencyList(int id){
        monthFrequencyBarChart.setData(analyze.monthFrequency(getSelectedSongsTrackList(), id));
    }
    public void loadYearFromSongAndMonthFrequencyList(){
        yearAndMonthFrequencyBarChart.setAll(analyze.yearAndMonth(getSelectedSongsTrackList()));
    }
    public void loadTimeFromSongFrequencyList(){
        timeFrequencyBarChart.setData(analyze.timeFrequency(getSelectedSongsTrackList()));
    }

    public void loadAlbumFrequencyList(){
        albumFrequencyList.setAll(analyze.firstLayerFrequencyMaker(infoList, homeController.ids.albums.getValue()));
    }
    public void loadPlayTimeFrequencyList(){
        totalPlayTime.setAll(analyze.playTimeAnalyzer(infoList, 6));
    }
    public void loadAveragePlayTimeList(){
        averagePlayTimeList.setAll(analyze.playTimeAnalyzer(infoList, 7));
    }
    public void loadSongFromAlbumFrequencyList(){
        songsFromAlbumFrequencyList.setAll(analyze.secondLayerFrequencyMaker(infoList, homeController.ids.albums.getValue(), getCurrentAlbumFrequencyData().getName()));
        songsFromAlbumFrequencyList.setAll(analyze.secondLayerFrequencyMaker(infoList, homeController.ids.albums.getValue(), getCurrentAlbumFrequencyData().getName()));
    }
    public void loadHeaderFromAlbum(){
        headerFromAlbum.set(analyze.headerInfoFromAlbum(infoList,  getCurrentSongFromAlbumFrequencyData().getName(), getCurrentAlbumFrequencyData().getName().substring(0,getCurrentAlbumFrequencyData().getName().indexOf(", by "))));
    }
    public void loadGenreFrequencyList(){
        genreFrequencyList.setAll(analyze.firstLayerFrequencyMaker(infoList, homeController.ids.genre.getValue()));
    }
    public void loadSongFromGenreFrequencyList(){
        songsFromGenreFrequencyList.setAll(analyze.secondLayerFrequencyMaker(infoList, homeController.ids.genre.getValue(),getCurrentGenreFrequencyData().getName()));
    }
    public void loadInfoList(String trackJson, String playCSV, boolean onlyPLAYEND){
        infoList.setAll(analyze.loadData(trackJson, playCSV, onlyPLAYEND));
    }

    public void resetCurrentSelections(){
        setCurrentSecondLayerFrequencyData(null);
        setCurrentTrackData(null);
        setCurrentSelectedSongTrackData(null);
        setCurrentFirstLayerArtistFrequencyData(null);
        setCurrentTrackInfoColumnData(null);
        setCurrentFirstLayerSongFrequencyData(null);
    }

}
