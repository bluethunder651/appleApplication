package com.applemusicplayv5;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class dataCreator {

    private SimpleStringProperty artistName, buildVersion, endReason, eventStart, eventType, featureName, mediaType, songName, endPosition, mediaDuration, startPosition, playDuration,playDurationInMills;
    private SimpleBooleanProperty offline;

    public dataCreator(String artistName, String buildVersion, String endPosition, String endReason, String eventStart, String eventType, String featureName, String mediaDuration, String mediaType, boolean offline, String playDuration, String playDurationInMills, String songName, String startPosition) {
        this.artistName = new SimpleStringProperty(artistName);
        this.buildVersion = new SimpleStringProperty(buildVersion);
        this.endReason = new SimpleStringProperty(endReason);
        this.eventStart = new SimpleStringProperty(eventStart);
        this.eventType = new SimpleStringProperty(eventType);
        this.featureName = new SimpleStringProperty(featureName);
        this.mediaType = new SimpleStringProperty(mediaType);
        this.offline = new SimpleBooleanProperty(offline);
        this.songName = new SimpleStringProperty(songName);
        this.endPosition = new SimpleStringProperty(endPosition);
        this.mediaDuration = new SimpleStringProperty(mediaDuration);
        this.startPosition = new SimpleStringProperty(startPosition);
        this.playDuration = new SimpleStringProperty(playDuration);
        this.playDurationInMills = new SimpleStringProperty(playDurationInMills);
    }

    public String getPlayDurationInMills() {
        return playDurationInMills.get();
    }

    public SimpleStringProperty playDurationInMillsProperty() {
        return playDurationInMills;
    }

    public void setPlayDurationInMills(String playDurationInMills) {
        this.playDurationInMills.set(playDurationInMills);
    }

    public SimpleBooleanProperty offlineProperty(){
        return offline;
    }

    public boolean isOffline() {
        return offline.get();
    }

    public void setOffline(boolean offline) {
        this.offline.set(offline);
    }

    public String getArtistName() {
        return artistName.get();
    }

    public SimpleStringProperty artistNameProperty() {
        return artistName;
    }

    public void setArtistName(String artistName) {
        this.artistName.set(artistName);
    }

    public String getBuildVersion() {
        return buildVersion.get();
    }

    public SimpleStringProperty buildVersionProperty() {
        return buildVersion;
    }

    public void setBuildVersion(String buildVersion) {
        this.buildVersion.set(buildVersion);
    }

    public String getEndReason() {
        return endReason.get();
    }

    public SimpleStringProperty endReasonProperty() {
        return endReason;
    }

    public void setEndReason(String endReason) {
        this.endReason.set(endReason);
    }

    public String getEventStart() {
        return eventStart.get();
    }

    public SimpleStringProperty eventStartProperty() {
        return eventStart;
    }

    public void setEventStart(String eventStart) {
        this.eventStart.set(eventStart);
    }

    public String getEventType() {
        return eventType.get();
    }

    public SimpleStringProperty eventTypeProperty() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType.set(eventType);
    }

    public String getFeatureName() {
        return featureName.get();
    }

    public SimpleStringProperty featureNameProperty() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName.set(featureName);
    }

    public String getMediaType() {
        return mediaType.get();
    }

    public SimpleStringProperty mediaTypeProperty() {
        return mediaType;
    }

    public void setMediaType(String mediaType) {
        this.mediaType.set(mediaType);
    }

    public String getSongName() {
        return songName.get();
    }

    public SimpleStringProperty songNameProperty() {
        return songName;
    }

    public void setSongName(String songName) {
        this.songName.set(songName);
    }

    public String getEndPosition() {
        return endPosition.get();
    }

    public SimpleStringProperty endPositionProperty() {
        return endPosition;
    }

    public void setEndPosition(String endPosition) {
        this.endPosition.set(endPosition);
    }

    public String getMediaDuration() {
        return mediaDuration.get();
    }

    public SimpleStringProperty mediaDurationProperty() {
        return mediaDuration;
    }

    public void setMediaDuration(String mediaDuration) {
        this.mediaDuration.set(mediaDuration);
    }

    public String getStartPosition() {
        return startPosition.get();
    }

    public SimpleStringProperty startPositionProperty() {
        return startPosition;
    }

    public void setStartPosition(String startPosition) {
        this.startPosition.set(startPosition);
    }

    public String getPlayDuration() {
        return playDuration.get();
    }

    public SimpleStringProperty playDurationProperty() {
        return playDuration;
    }

    public void setPlayDuration(String playDuration) {
        this.playDuration.set(playDuration);
    }
}
