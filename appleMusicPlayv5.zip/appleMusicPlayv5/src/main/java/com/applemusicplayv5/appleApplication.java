package com.applemusicplayv5;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class appleApplication extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        BorderPane root;
        FXMLLoader menuLoader = new FXMLLoader(getClass().getResource("Menu.fxml"));
        menuLoader.load();
        menuController menuController = menuLoader.getController();
        root = menuLoader.getRoot();


        Scene scene = new Scene(root, 1920,1020);
        stage.setTitle("Apple Music Analyzer");
        stage.setScene(scene);
        stage.setMaximized(true);
        menuController.init();
        stage.show();

    }
}
