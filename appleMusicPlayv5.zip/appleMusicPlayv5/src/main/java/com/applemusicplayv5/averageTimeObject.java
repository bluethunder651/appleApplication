package com.applemusicplayv5;

import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;

public class averageTimeObject {
    private SimpleStringProperty name;
    private SimpleLongProperty average;

    public averageTimeObject(String name, long average){
        this.name = new SimpleStringProperty(name);
        this.average = new SimpleLongProperty(average);
    }

    public String getName() {
        return name.get();
    }

    public SimpleStringProperty nameProperty() {
        return name;
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public long getAverage() {
        return average.get();
    }

    public SimpleLongProperty averageProperty() {
        return average;
    }

    public void setAverage(long average) {
        this.average.set(average);
    }
}
