package com.applemusicplayv5;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class trackInfoColumn {

    private SimpleStringProperty field, output;

    public trackInfoColumn(String field, String output) {
        this.field = new SimpleStringProperty(field);
        this.output = new SimpleStringProperty(output);
    }

    public String getField() {
        return field.get();
    }

    public SimpleStringProperty fieldProperty() {
        return field;
    }

    public void setField(String field) {
        this.field.set(field);
    }

    public String getOutput() {
        return output.get();
    }

    public SimpleStringProperty outputProperty() {
        return output;
    }

    public void setOutput(String output) {
        this.output.set(output);
    }
}
