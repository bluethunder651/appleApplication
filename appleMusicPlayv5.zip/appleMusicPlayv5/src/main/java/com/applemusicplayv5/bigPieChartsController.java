package com.applemusicplayv5;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;


public class bigPieChartsController {

    @FXML private PieChart pieChart;

    @FXML private Label label;
    @FXML private Button home;
    @FXML private Button back;
    @FXML private Button next;
    @FXML private Button previous;

    private dataModel model;

    public void init(dataModel model){
        if(this.model!=null){
            throw new IllegalStateException("must be null");
        }
        this.model = model;

        AtomicInteger count = new AtomicInteger();
        int max = 4;

        switchPieChart(count.get());

        back.setOnAction(actionEvent -> {
            try {
                homeButton(model);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        home.setOnAction(actionEvent -> {
            try {
                homeButton(model);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        next.setOnAction(actionEvent -> {
            if(count.get() !=max)
                count.getAndIncrement();
            else
                count.set(0);
            switchPieChart(count.get());
        });
        previous.setOnAction(actionEvent -> {
            if(count.get() !=0)
                count.getAndDecrement();
            else
                count.set(max);
            switchPieChart(count.get());
        });

    }

    public void homeButton(dataModel model) throws IOException {
        FXMLLoader home = new FXMLLoader(getClass().getResource("home.fxml"));
        home.load();
        homeController homeController = home.getController();
        homeController.init(model);
        pieChart.getScene().setRoot(home.getRoot());
    }

    public void switchPieChart(int count){
        switch(count){
            case 0:
                pieChart.setData(model.getArtistPieChart());
                pieChart.setTitle("Top 2.5% of Artists");
                break;
            case 1:
                pieChart.setData(model.getSongPieChart());
                pieChart.setTitle("Top 1% of Songs");
                break;
            case 2:
                pieChart.setData(model.getGenrePieChart());
                pieChart.setTitle("Top Genres");
                break;
            case 3:
                pieChart.setData(model.getAlbumPieChart());
                pieChart.setTitle("Top 5% of Albums");
                break;
            case 4:
                pieChart.setData(model.getEndReasonPieChart());
                pieChart.setTitle("Top End Reasons");
                break;
        }
        label.setText("");
        for(final PieChart.Data data : pieChart.getData()){
            data.getNode().addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                label.setBackground(new Background(new BackgroundFill(Color.GAINSBORO, new CornerRadii(5), Insets.EMPTY)));
                label.setTranslateX(e.getSceneX() - label.getLayoutX());
                label.setTranslateY(e.getSceneY() - label.getLayoutY());
                label.setText(data.getName() + ", " + (int)data.getPieValue() + " plays");
            });
        }
    }
}
