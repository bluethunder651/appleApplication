package com.applemusicplayv5;

import javafx.beans.property.SimpleStringProperty;

public class playTimeObject {

    private SimpleStringProperty name, playTime;

    public playTimeObject(String name, String playTime){
        this.name = new SimpleStringProperty(name);
        this.playTime = new SimpleStringProperty(playTime);
    }

    public String getName() {
        return name.get();
    }

    public SimpleStringProperty nameProperty() {
        return name;
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public String getPlayTime() {
        return playTime.get();
    }

    public SimpleStringProperty playTimeProperty() {
        return playTime;
    }

    public void setPlayTime(String playTime) {
        this.playTime.set(playTime);
    }
}
