package com.applemusicplayv5;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;

import java.io.IOException;

public class songController {

    @FXML private TableView<frequencyList> songTable;
    @FXML private TableColumn<frequencyList, String> songName;
    @FXML private TableColumn<frequencyList, Integer> frequency;

    @FXML private VBox vBox;
    @FXML private TextField input;
    @FXML private Button back;
    @FXML private Button home;
    @FXML private Label header;

    private dataModel model;

    /*public void init(dataModel model, int id){
        System.out.println("Song Controller incoming ID: " + id);
        if(this.model!=null){
            throw new IllegalStateException("must be null");
        }
        this.model = model;

        songName.setCellValueFactory(new PropertyValueFactory<>("name"));
        frequency.setCellValueFactory(new PropertyValueFactory<>("frequency"));

        songTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        songName.setMaxWidth(1f*Integer.MAX_VALUE*75);
        frequency.setMaxWidth(1f*Integer.MAX_VALUE*25);

        songTable.prefHeightProperty().bind(vBox.heightProperty());

        ObservableList<frequencyList> fList = FXCollections.observableArrayList();

        switch(id){
            case 0:
                fList = model.getSecondLayerFrequencyList();
                songTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
                    if (newSelection != null) {
                        model.setCurrentSecondLayerFrequencyData(newSelection);
                        try {
                            fullTable(model,id);
                        } catch (IOException exception) {
                            exception.printStackTrace();
                        }
                    }
                });
                header.setText(model.getCurrentFirstLayerFrequencyArtistData().getName());
                break;
            case 1:
                fList = model.getFirstLayerSongFrequencyList();
                songTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
                    if(newSelection!=null){
                        model.setCurrentFirstLayerArtistFrequencyData(newSelection);
                        try {
                            fullTable(model, id);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                header.setText("Songs");
                break;
            case 2:
                fList = model.getSongsFromGenreFrequencyList();
                songTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {

                    if(newSelection!=null){
                        model.setCurrentSongFromGenreFrequencyData(newSelection);
                        try {
                            fullTable(model, id);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                header.setText(model.getCurrentGenreFrequencyData().getName());
                break;
            case 3:
                fList = model.getSongsFromAlbumFrequencyList();
                songTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
                    if(newSelection!=null){
                        model.setCurrentSongFromAlbumFrequencyData(newSelection);
                        try {
                            fullTable(model, id);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                header.setText(model.getCurrentAlbumFrequencyData().getName());
                break;
        }

        FilteredList<frequencyList> data = new FilteredList<>(fList, b -> true);

        input.textProperty().addListener(((observableValue, oldValue, newValue) -> {
            data.setPredicate(frequencyList -> {
                if(newValue == null || newValue.isEmpty()){
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();
                if(frequencyList.getName().toLowerCase().indexOf(lowerCaseFilter)!=-1){
                    return true;
                }else if(String.valueOf(frequencyList.getFrequency()).indexOf(lowerCaseFilter)!=-1){
                    return true;
                }else{
                    return false;
                }
            });
        }));

        songTable.setItems(data);
        songTable.setFocusTraversable(false);

        back.setOnAction(actionEvent -> {
            try {
                changeScreen(model, id);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        home.setOnAction(actionEvent -> {
            try {
                changeScreen(model, 1);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });


    }
    public void changeScreen(dataModel model, int id) throws IOException {
        switch(id){
            case 0:
                FXMLLoader artists = new FXMLLoader(getClass().getResource("artists.fxml"));
                artists.load();
                artistsController artistsController = artists.getController();
                artistsController.init(model);
                songTable.getScene().setRoot(artists.getRoot());
                break;
            case 1:
                FXMLLoader home = new FXMLLoader(getClass().getResource("home.fxml"));
                home.load();
                homeController homeController = home.getController();
                homeController.init(model);
                songTable.getScene().setRoot(home.getRoot());
                break;
            case 2:
                FXMLLoader genre = new FXMLLoader(getClass().getResource("genre.fxml"));
                genre.load();
                genreController genreController = genre.getController();
                genreController.init(model);
                songTable.getScene().setRoot(genre.getRoot());
                break;
            case 3:
                FXMLLoader album = new FXMLLoader(getClass().getResource("albumFromMenu.fxml"));
                album.load();
                albumFromMenuController albumFromMenuController = album.getController();
                albumFromMenuController.init(model);
                songTable.getScene().setRoot(album.getRoot());
                break;
        }
    }
    public void fullTable(dataModel model, int id) throws IOException{
        FXMLLoader full = new FXMLLoader(getClass().getResource("fullTrackInfo.fxml"));
        full.load();
        fullTrackInfoController fullTrackInfoController = full.getController();
        switch(id){
            case 0:
                model.loadSelectedSongTrackList();
                model.loadTrackInfoColumnList();
                break;
            case 1:
                model.loadSelectedSongTrackListFromSongMenu();
                model.loadTrackInfoColumnListFromSongMenu();
                break;
            case 2:
                model.loadSelectedSongTrackListFromGenre();
                model.loadTrackInfoColumnListFromGenre();
                break;
            case 3:
                model.loadSelectedSongTrackListFromAlbumMenu();
                model.loadTrackInfoColumnListFromAlbumMenu();
                model.loadHeaderFromAlbum();
                break;
        }
        fullTrackInfoController.init(model, id);
        if(songTable.getScene()!=null)
            songTable.getScene().setRoot(full.getRoot());
    }*/

}
