package com.applemusicplayv5;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

import java.io.IOException;

public class listWithPieChartController {

    @FXML private TableView<frequencyList> table;
    @FXML private TableColumn<frequencyList, String> name;
    @FXML private TableColumn<frequencyList, Integer> frequency;
    @FXML private TableView<playTimeObject> playTable;
    @FXML private TableColumn<playTimeObject, String> playTimeName;
    @FXML private TableColumn<playTimeObject, String> playTime;
    @FXML private PieChart pieChart;

    @FXML private Pane pane;
    @FXML private VBox vBox;
    @FXML private TextField input;
    @FXML private Button back;
    @FXML private Button home;
    @FXML private Label header;
    @FXML private Label label;

    private dataModel model;

    public void init(dataModel model, int id, int layer){
        if(this.model!=null){
            throw new IllegalStateException("Model must be null.");
        }
        this.model = model;

        name.setCellValueFactory(new PropertyValueFactory<>("name"));
        frequency.setCellValueFactory(new PropertyValueFactory<>("frequency"));

        playTimeName.setCellValueFactory(new PropertyValueFactory<>("name"));
        playTime.setCellValueFactory(new PropertyValueFactory<>("playTime"));

        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        name.setMaxWidth(1f*Integer.MAX_VALUE*75);
        frequency.setMaxWidth(1f*Integer.MAX_VALUE*25);

        input.prefWidthProperty().bind(vBox.widthProperty());
        pane.prefWidthProperty().bind(vBox.widthProperty());
        pane.prefHeightProperty().bind(vBox.heightProperty());

        playTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        playTimeName.setMaxWidth(1f*Integer.MAX_VALUE*75);
        playTime.setMaxWidth(1f*Integer.MAX_VALUE*25);

        ObservableList<frequencyList> fList = FXCollections.observableArrayList();
        ObservableList<playTimeObject> pList = FXCollections.observableArrayList();
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();

        if(layer == 0) {
            switch (id) {
                case 0:
                    fList = model.getFirstLayerArtistFrequencyList();
                    table.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
                        if (newSelection != null) {
                            model.setCurrentFirstLayerArtistFrequencyData(newSelection);
                            try {
                                songTable(model, id, layer+1);
                            } catch (IOException exception) {
                                exception.printStackTrace();
                            }
                        }
                    });
                    model.loadArtistPieChartDataList(15);
                    pieChartData = model.getArtistPieChart();
                    pieChart.setTitle("Top 15 Artists");
                    name.setText("Artists");
                    header.setText("Artists");
                    break;
                case 2:
                    fList = model.getGenreFrequencyList();
                    table.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
                        model.setCurrentGenreFrequencyData(newSelection);
                        try {
                            songTable(model, id, layer+1);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    });
                    model.loadGenrePieChartDataList(10);
                    pieChartData = model.getGenrePieChart();
                    pieChart.setTitle("Top 10 Genres");
                    header.setText("Genre");
                    name.setText("Genre");
                    break;
                case 3:
                    fList = model.getAlbumFrequencyList();
                    table.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
                        if(newSelection!=null){
                            model.setCurrentAlbumFrequencyData(newSelection);
                            try {
                                songTable(model, id, layer+1);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    model.loadAlbumPieChartDataList(15);
                    pieChartData = model.getAlbumPieChart();
                    pieChart.setTitle("Top 15 Albums");
                    header.setText("Albums");
                    name.setText("Albums");
                    break;
            }
        }
        else{
            switch (id) {
                case 0 -> {
                    fList = model.getSecondLayerFrequencyList();
                    table.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
                        if (newSelection != null) {
                            model.setCurrentSecondLayerFrequencyData(newSelection);
                            try {
                                fullTable(model, id, layer + 1);
                            } catch (IOException exception) {
                                exception.printStackTrace();
                            }
                        }
                    });
                    header.setText(model.getCurrentFirstLayerFrequencyArtistData().getName());
                }
                case 1 -> {
                    fList = model.getFirstLayerSongFrequencyList();
                    table.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
                        if (newSelection != null) {
                            model.setCurrentFirstLayerArtistFrequencyData(newSelection);
                            try {
                                fullTable(model, id, layer + 1);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    model.loadSongPieChartDataList(15);
                    pieChartData = model.getSongPieChart();
                    pieChart.setTitle("Top 15 Songs");
                    header.setText("Songs");
                }
                case 2 -> {
                    fList = model.getSongsFromGenreFrequencyList();
                    table.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {

                        if (newSelection != null) {
                            model.setCurrentSongFromGenreFrequencyData(newSelection);
                            try {
                                fullTable(model, id, layer + 1);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    header.setText(model.getCurrentGenreFrequencyData().getName());
                }
                case 3 -> {
                    fList = model.getSongsFromAlbumFrequencyList();
                    table.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
                        if (newSelection != null) {
                            model.setCurrentSongFromAlbumFrequencyData(newSelection);
                            try {
                                fullTable(model, id, layer + 1);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    header.setText(model.getCurrentAlbumFrequencyData().getName());
                }
                case 6 -> {
                    pList = model.getTotalPlayTime();
                    playTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
                        if (newSelection != null) {
                            model.setCurrentTotalPlayTimeList(newSelection);
                            try {
                                fullTable(model, id, layer + 1);
                            } catch (IOException exception) {
                                exception.printStackTrace();
                            }
                        }
                    });
                    model.loadTotalTimePieChartDataList(15);
                    pieChartData = model.getTotalTimePieChart();
                    pieChart.setTitle("Top 15 Songs");
                    pieChart.setLabelsVisible(false);
                    header.setText("Songs by Total Play Time");
                    playTimeName.setText("Song");
                    playTime.setText("Play Time");
                }
                case 7 -> {
                    pList = model.getAveragePlayTimeList();
                    playTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
                        if(newSelection!=null){
                            model.setCurrentAveragePlayTimeListData(newSelection);
                            try{
                                fullTable(model, id, layer +1);
                            } catch (IOException exception) {
                                exception.printStackTrace();
                            }
                        }
                    });
                    model.loadAverageTimePieChartDataList(15);
                    pieChartData = model.getAverageTimePieChart();
                    pieChart.setTitle("Top 15 Songs");
                    header.setText("Songs by Average Play Time");
                    playTimeName.setText("Song");
                    playTime.setText("Average Play Time");
                }
                case 8 -> {
                    System.out.println("got here");
                    pList = model.getReleaseDateList();
                    System.out.println(pList.size());
                    playTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
                        if(newSelection!=null){
                            model.setCurrentReleaseDateListData(newSelection);
                            try{
                                fullTable(model, id, layer + 1);
                            }catch (IOException e){
                                e.printStackTrace();
                            }
                        }
                    });
                    header.setText("Songs by Release Date");
                    playTimeName.setText("Songs");
                    playTime.setText("Release Date");
                }
            }
            name.setText("Songs");
        }

        if(id!=6 && id!=7 && id!= 8) {
            playTable.setVisible(false);
            table.setVisible(true);
            FilteredList<frequencyList> data = new FilteredList<>(fList, b -> true);

            input.textProperty().addListener(((observableValue, oldValue, newValue) -> {
                data.setPredicate(frequencyList -> {
                    if (newValue == null || newValue.isEmpty()) {
                        return true;
                    }
                    String lowerCaseFilter = newValue.toLowerCase();
                    if (frequencyList.getName().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                        return true;
                    } else if (String.valueOf(frequencyList.getFrequency()).indexOf(lowerCaseFilter) != -1) {
                        return true;
                    } else {
                        return false;
                    }
                });
            }));

            pieChart.setData(pieChartData);

            table.setItems(data);
            table.setFocusTraversable(false);
        }
        else{
            table.setVisible(false);
            playTable.setVisible(true);
            FilteredList<playTimeObject> data = new FilteredList<>(pList, b -> true);

            input.textProperty().addListener((observableValue, oldValue, newValue) -> {
                data.setPredicate(playTimeObject -> {
                    if(newValue==null || newValue.isEmpty()){
                        return true;
                    }
                    String lowerCaseFilter = newValue.toLowerCase();
                    if(playTimeObject.getName().toLowerCase().indexOf(lowerCaseFilter) != -1){
                        return true;
                    }else if(playTimeObject.getPlayTime().toLowerCase().indexOf(lowerCaseFilter) != -1){
                        return true;
                    }else{
                        return false;
                    }
                });
            });

            pieChart.setData(pieChartData);

            playTable.setItems(data);
            playTable.setFocusTraversable(false);
        }

        table.prefHeightProperty().bind(pane.heightProperty());
        table.prefWidthProperty().bind(pane.widthProperty());
        playTable.prefHeightProperty().bind(pane.heightProperty());
        playTable.prefWidthProperty().bind(pane.widthProperty());

        for(final PieChart.Data data : pieChart.getData()){
            data.getNode().addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                label.setBackground(new Background(new BackgroundFill(Color.GAINSBORO, new CornerRadii(5), Insets.EMPTY)));
                label.setTranslateX(e.getSceneX() - label.getLayoutX());
                label.setTranslateY(e.getSceneY() - label.getLayoutY());
                if(id!=6 && id != 7)
                label.setText(data.getName() + ", " + (int)data.getPieValue() + " plays");
                else
                    label.setText(data.getName());
            });
        }


        back.setOnAction(actionEvent -> {
            try {
                changeScreen(model, id, layer);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        home.setOnAction(actionEvent -> {
            try {
                changeScreen(model, id, 0);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

    }

    public void songTable(dataModel model, int id, int layer) throws IOException {
        FXMLLoader song = new FXMLLoader(getClass().getResource("listWithPieChart.fxml"));
        song.load();
        listWithPieChartController list = song.getController();
        switch(id){
            case 0:
                model.loadSecondLayerFrequencyList();
                break;
            case 2:
                model.loadSongFromGenreFrequencyList();
                break;
            case 3:
                model.loadSongFromAlbumFrequencyList();
                break;
        }
        list.init(model, id, layer);
        if(table.getScene()!=null)
            table.getScene().setRoot(song.getRoot());
    }

    public void fullTable(dataModel model, int id, int layer) throws IOException{
        FXMLLoader full = new FXMLLoader(getClass().getResource("fullTrackInfo.fxml"));
        full.load();
        fullTrackInfoController fullTrackInfoController = full.getController();
        switch(id){
            case 0:
                model.loadSelectedSongTrackList();
                model.loadTrackInfoColumnList();
                break;
            case 1:
                model.loadSelectedSongTrackListFromSongMenu();
                model.loadTrackInfoColumnListFromSongMenu();
                break;
            case 2:
                model.loadSelectedSongTrackListFromGenre();
                model.loadTrackInfoColumnListFromGenre();
                break;
            case 3:
                model.loadSelectedSongTrackListFromAlbumMenu();
                model.loadTrackInfoColumnListFromAlbumMenu();
                model.loadHeaderFromAlbum();
                break;
            case 6:
                model.loadSelectedSongTrackListFromPlayTime();
                model.loadTrackInfoColumnListFromPlayTime();
                break;
            case 7:
                model.loadSelectedSongTrackListFromAverageTime();
                model.loadTrackInfoColumnListFromAverageTime();
                break;
            case 8:
                model.loadSelectedSongTrackListFromReleaseDate();
                model.loadTrackInfoColumnListFromReleaseDate();
                break;
        }
        fullTrackInfoController.init(model, id);
        if(table.getScene()!=null)
            table.getScene().setRoot(full.getRoot());
    }
    public void changeScreen(dataModel model, int id, int layer) throws IOException {
        if(layer == 0 || id == 1 || id ==6 || id == 7 || id == 8){
            FXMLLoader home = new FXMLLoader(getClass().getResource("home.fxml"));
            home.load();
            homeController homeController = home.getController();
            homeController.init(model);
            table.getScene().setRoot(home.getRoot());
        }else{
            FXMLLoader lists = new FXMLLoader(getClass().getResource("listWithPieChart.fxml"));
            lists.load();
            listWithPieChartController list = lists.getController();
            list.init(model, id, layer-1);
            if(table.getScene()!=null)
                table.getScene().setRoot(lists.getRoot());
        }
    }

}
