package com.applemusicplayv5;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

import java.io.IOException;


public class dateBarChartsController {

    @FXML private BarChart days;
    @FXML private BarChart months;
    @FXML private BarChart yearsAndMonths;
    @FXML private BarChart time;
    @FXML private BarChart year;
    @FXML private NumberAxis yearY;
    @FXML private NumberAxis monthY;
    @FXML private NumberAxis YAMY;
    @FXML private NumberAxis timeY;
    @FXML private Pane pane;

    @FXML private Button back;
    @FXML private Button home;
    @FXML private Label header;


    private dataModel model;

    public void init(dataModel model, int id){
        if(this.model!=null){
            throw new IllegalStateException("must be null");
        }
        this.model = model;

        switch (id) {
            case 0, 1, 2, 3, 4, 5, 6, 7, 8 -> {
                days.getData().addAll(model.getDayFrequencyBarChart());
                months.getData().addAll(model.getMonthFrequencyBarChart());
                yearsAndMonths.getData().addAll(model.getYearAndMonthFrequencyBarChart());
                time.getData().addAll(model.getTimeFrequencyBarChart());
                yearsAndMonths.prefWidthProperty().bind(pane.widthProperty());
                yearsAndMonths.prefHeightProperty().bind(pane.heightProperty());
                yearsAndMonths.setVisible(true);
                time.setVisible(true);
                year.setVisible(false);
            }
            case 9 -> {
                days.getData().addAll(model.getDayFrequencyBarChart());
                year.getData().addAll(model.getYearFrequencyBarChart());
                months.getData().addAll(model.getMonthFrequencyBarChart());
                time.getData().addAll(model.getTimeFrequencyBarChart());
                year.prefWidthProperty().bind(pane.widthProperty());
                year.prefHeightProperty().bind(pane.heightProperty());
                days.getYAxis().setLabel("Songs");
                days.setTitle("Songs by Day");
                days.getXAxis().setLabel("Day");
                months.getYAxis().setLabel("Songs");
                months.setTitle("Songs by Month");
                months.getXAxis().setLabel("Month");
                yearsAndMonths.setVisible(false);
                time.setVisible(false);
                year.setVisible(true);
            }
        }

        if(id==homeController.ids.home.getValue() || id == homeController.ids.releaseDateFromHome.getValue())
            header.setVisible(false);
        else{
            header.setText(model.getHeader());
        }


        back.setOnAction(actionEvent -> {
            try {
                backButton(model, id, false);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        home.setOnAction(actionEvent -> {
            try {
                homeButton(model);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    public void init(dataModel model, int id, boolean fromRandom){
        if(this.model!=null){
            throw new IllegalStateException("must be null");
        }
        this.model = model;

        year.getData().addAll(model.getYearFrequencyBarChart());
        days.getData().addAll(model.getDayFrequencyBarChart());
        months.getData().addAll(model.getMonthFrequencyBarChart());
        yearsAndMonths.getData().addAll(model.getYearAndMonthFrequencyBarChart());
        time.getData().addAll(model.getTimeFrequencyBarChart());


        header.setText(model.getHeader());


        back.setOnAction(actionEvent -> {
                try {
                    backButton(model, id, fromRandom);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

        home.setOnAction(actionEvent -> {
            try {
                homeButton(model);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }


    public void homeButton(dataModel model) throws IOException {
        FXMLLoader home = new FXMLLoader(getClass().getResource("home.fxml"));
        home.load();
        homeController homeController = home.getController();
        homeController.init(model);
        days.getScene().setRoot(home.getRoot());
    }
    public void backButton(dataModel model, int id, boolean fromRandom) throws IOException {
        if (fromRandom) {
            FXMLLoader full = new FXMLLoader(getClass().getResource("fullTrackInfo.fxml"));
            full.load();
            fullTrackInfoController fullTrackInfoController = full.getController();
            fullTrackInfoController.init(model, 4);
            days.getScene().setRoot(full.getRoot());
        } else {
            switch (id) {
                case 0:
                case 1:
                case 2:
                case 3:
                case 6:
                case 7:
                case 8:
                    FXMLLoader full = new FXMLLoader(getClass().getResource("fullTrackInfo.fxml"));
                    full.load();
                    fullTrackInfoController fullTrackInfoController = full.getController();
                    fullTrackInfoController.init(model, id);
                    days.getScene().setRoot(full.getRoot());
                    break;
                case 4:
                case 9:
                    FXMLLoader home = new FXMLLoader(getClass().getResource("home.fxml"));
                    home.load();
                    homeController homeController = home.getController();
                    homeController.init(model);
                    days.getScene().setRoot(home.getRoot());
                    break;
            }

        }
    }


}
