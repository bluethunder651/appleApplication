package com.applemusicplayv5;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;

import java.io.IOException;

public class homeController {

    @FXML
    private Button artists;
    @FXML private Button songs;
    @FXML private Button pieCharts;
    @FXML private Button randomSongs;
    @FXML private Button barChartDate;
    @FXML private Button albums;
    @FXML private Button genre;
    @FXML private Button menu;
    @FXML private Button playTime;
    @FXML private Button average;
    @FXML private Button releaseDate;
    @FXML private Button releaseDateBarChart;

    private dataModel model;

    public enum ids{

        artists(0),
        songs(1),
        genre(2),
        albums(3),
        home(4),
        endReason(5),
        playTime(6),
        averageTime(7),
        releaseDate(8),
        releaseDateFromHome(9);

        private final int value;
        ids(int value) {this.value = value;}
        public int getValue() {return value;}
    }

    public void init(dataModel model){
        if(this.model!=null){
            throw new IllegalStateException("model should be null");
        }
        this.model = model;

        model.resetCurrentSelections();

        artists.setOnAction(actionEvent -> {
            try {
                artistsScreen(model);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        songs.setOnAction(actionEvent -> {
            try{
                songScreen(model);
            } catch (IOException exception) {
                exception.printStackTrace();
            }
        });
        pieCharts.setOnAction(actionEvent -> {
            try {
                pieChartScreen(model);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        randomSongs.setOnAction(actionEvent -> {
            try {
                randomSongsScreen(model);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        barChartDate.setOnAction(actionEvent -> {
            try {
                barChartDateScreen(model);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        albums.setOnAction(actionEvent -> {
            try {
                albumScreen(model);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        genre.setOnAction(actionEvent -> {
            try {
                genreScreen(model);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        menu.setOnAction(actionEvent -> {
            try {
                menuScreen();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        playTime.setOnAction(actionEvent -> {
            try {
                playTimeScreen(model);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        average.setOnAction(actionEvent -> {
            try {
                averagePlayScreen(model);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        releaseDate.setOnAction(actionEvent -> {
            try {
                releaseDateScreen(model);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        releaseDateBarChart.setOnAction(actionEvent -> {
            try {
                ReleaseDateBarChartScreen(model);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    public void artistsScreen(dataModel model) throws IOException {
        FXMLLoader artist = new FXMLLoader(getClass().getResource("listWithPieChart.fxml"));
        artist.load();
        listWithPieChartController list = artist.getController();
        list.init(model, ids.artists.value, 0);
        artists.getScene().setRoot(artist.getRoot());
    }
    public void songScreen(dataModel model) throws IOException{
        FXMLLoader artist = new FXMLLoader(getClass().getResource("listWithPieChart.fxml"));
        artist.load();
        listWithPieChartController list = artist.getController();
        list.init(model, ids.songs.value, 1);
        artists.getScene().setRoot(artist.getRoot());
    }
    public void pieChartScreen(dataModel model) throws IOException{
        FXMLLoader pieCharts = new FXMLLoader(getClass().getResource("bigPieCharts.fxml"));
        pieCharts.load();
        model.loadSongPieChartDataList((int)(model.getFirstLayerSongFrequencyList().size()*.01));
        model.loadArtistPieChartDataList((int)(model.getFirstLayerArtistFrequencyList().size()*.025));
        model.loadGenrePieChartDataList((int)(model.getGenreFrequencyList().size()*.5));
        model.loadAlbumPieChartDataList((int)(model.getAlbumFrequencyList().size() * .05));
        model.loadEndReasonPieChartDataList(model.getEndReasonFrequencyList().size());
        bigPieChartsController bigPieChartsController = pieCharts.getController();
        bigPieChartsController.init(model);
        artists.getScene().setRoot(pieCharts.getRoot());
    }
    public void randomSongsScreen(dataModel model) throws IOException{
        FXMLLoader full = new FXMLLoader(getClass().getResource("fullTrackInfo.fxml"));
        full.load();
        fullTrackInfoController fullTrackInfoController = full.getController();
        frequencyList choice = analyze.illusionOfChoice(model.getFirstLayerSongFrequencyList());
        model.setCurrentFirstLayerArtistFrequencyData(choice);
        model.loadSelectedSongTrackListFromSongMenu();
        model.loadTrackInfoColumnListFromSongMenu();
        fullTrackInfoController.init(model, ids.home.value);
        artists.getScene().setRoot(full.getRoot());
    }
    public void barChartDateScreen(dataModel model) throws IOException{
        FXMLLoader barChart = new FXMLLoader(getClass().getResource("dateBarCharts.fxml"));
        barChart.load();
        dateBarChartsController dateBarChartsController = barChart.getController();
        model.loadDayFrequencyList(ids.home.getValue());
        model.loadMonthFrequencyList(ids.home.getValue());
        model.loadTimeFrequencyList();
        model.loadYearAndMonthFrequencyList();
        dateBarChartsController.init(model, ids.home.value);
        artists.getScene().setRoot(barChart.getRoot());
    }
    public void albumScreen(dataModel model) throws IOException{
        FXMLLoader genre = new FXMLLoader(getClass().getResource("listWithPieChart.fxml"));
        genre.load();
        listWithPieChartController list = genre.getController();
        list.init(model, ids.albums.value, 0);
        artists.getScene().setRoot(genre.getRoot());
    }
    public void genreScreen(dataModel model) throws IOException{
        FXMLLoader album = new FXMLLoader(getClass().getResource("listWithPieChart.fxml"));
        album.load();
        listWithPieChartController list = album.getController();
        list.init(model, ids.genre.value, 0);
        artists.getScene().setRoot(album.getRoot());
    }
    public void menuScreen()throws IOException{
        FXMLLoader menu = new FXMLLoader(getClass().getResource("Menu.fxml"));
        menu.load();
        menuController menuController = menu.getController();
        menuController.init();
        artists.getScene().setRoot(menu.getRoot());
    }
    public void playTimeScreen(dataModel model)throws IOException{
        FXMLLoader playTime = new FXMLLoader(getClass().getResource("listWithPieChart.fxml"));
        playTime.load();
        listWithPieChartController list = playTime.getController();
        list.init(model, ids.playTime.getValue(), 1);
        artists.getScene().setRoot(playTime.getRoot());
    }
    public void averagePlayScreen(dataModel model)throws IOException{
        FXMLLoader averagePlay = new FXMLLoader(getClass().getResource("listWithPieChart.fxml"));
        averagePlay.load();
        listWithPieChartController list = averagePlay.getController();
        list.init(model, ids.averageTime.getValue(), 1);
        artists.getScene().setRoot(averagePlay.getRoot());
    }
    public void releaseDateScreen(dataModel model)throws IOException{
        FXMLLoader releaseDate = new FXMLLoader(getClass().getResource("listWithPieChart.fxml"));
        releaseDate.load();
        listWithPieChartController list = releaseDate.getController();
        list.init(model, ids.releaseDate.getValue(), 1);
        artists.getScene().setRoot(releaseDate.getRoot());
    }
    public void ReleaseDateBarChartScreen(dataModel model)throws IOException{
        FXMLLoader releaseDate = new FXMLLoader(getClass().getResource("dateBarCharts.fxml"));
        releaseDate.load();
        model.loadDayFromObjectList();
        model.loadMonthFromObjectList();
        //model.loadTimeFrequencyList();
        model.loadYearFrequencyList();
        dateBarChartsController list = releaseDate.getController();
        list.init(model, ids.releaseDateFromHome.getValue());
        artists.getScene().setRoot(releaseDate.getRoot());
    }
}
