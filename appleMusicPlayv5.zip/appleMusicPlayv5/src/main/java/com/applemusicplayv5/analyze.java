package com.applemusicplayv5;

import java.io.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.NumberFormat;
import java.time.*;
import java.time.format.TextStyle;
import java.util.*;

import com.github.sisyphsu.dateparser.DateParserUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;

public class analyze {

    public static ObservableList<dataObject> loadData(String trackJson, String playCSV, boolean onlyPLAYEND) {

        String trackFile = readFileAsString(trackJson);
        String csvFile = readFileAsString(playCSV);

        List<String> removal = new ArrayList<>(Arrays.asList("\"Grouping\" : \"\",","\"Comments\" : \"\",","\"Beats Per Minute\" : 0,","\"Rating\" : 0,","\"Album Rating\" : 0,","\"Album Like Rating\" : \"UNDEFINED\",","\"Track Like Rating\" : \"UNDEFINED\",","\"Album Rating Method\" : \"Calculated\",","\"Work Name\" : \"\",","\"Movement Name\" : \"\",","\"Movement Number\" : 0,","\"Movement Count\" : 0,","\"Display Work Name\" : false,","\"Remember Playback Position\" : false,", "[ {", "} ]"));
        String[] trackInfo = trackFile.split("\\s*},\\s*\\{\\s*");
        String[] csvInfo = csvFile.split("\\n");

        ObservableList<dataObject> returnValue = FXCollections.observableArrayList();
        ObservableList<songInfoClass> songInfo = FXCollections.observableArrayList();
        ObservableList<dataCreator> dataCreators = FXCollections.observableArrayList();

        String type;
        int y = 0;
        List<Integer> strings = Arrays.asList(0,2,3,4,5,6,8,9,10,11,12,21,22,23,24,25,27,29,31,32);
        List<Integer> ints = Arrays.asList(1,13,14,15,16,17,18,19,20,26,33,34,35);
        List<Integer> booleans = Arrays.asList(7,28,30);
        int[] z = {2,3,6,7,11,12,13,15,16,20,21,31,33,99};
        int k = 0;
        List<Integer> strs = Arrays.asList(2,3,7,11,12,13,16,31);
        List<Integer> integers = Arrays.asList(6,15,19,33);



        for(String s : trackInfo){
            boolean checker = true;
            List<String> info = new LinkedList<>(Arrays.asList(s.split("\\s*\\n\\s*")));
            info.removeAll(removal);
            List<String> output = new ArrayList<>();
            for (int i = 0; i < 37; i++) {
                type = switch (i) {
                    case 0 -> "Content Type";
                    case 1 -> "Track Identifier";
                    case 2 -> "Title";
                    case 3 -> "Sort Name";
                    case 4 -> "Artist";
                    case 5 -> "Sort Artist";
                    case 6 -> "Composer";
                    case 7 -> "Is Part of Compilation";
                    case 8 -> "Album";
                    case 9 -> "Sort Album";
                    case 10 -> "Album Artist";
                    case 11 -> "Genre";
                    case 12 -> "Grouping";
                    case 13 -> "Track Year";
                    case 14 -> "Track Number On Album";
                    case 15 -> "Track Count On Album";
                    case 16 -> "Disc Number Of Album";
                    case 17 -> "Disc Count Of Album";
                    case 18 -> "Beats Per Minute";
                    case 19 -> "Track Duration";
                    case 20 -> "Track Play Count";
                    case 21 -> "Date Added To Library";
                    case 22 -> "Date Added To iCloud Music Library";
                    case 23 -> "Last Modified Date";
                    case 24 -> "Last Played Date";
                    case 25 -> "Purchase Date";
                    case 26 -> "Skip Count";
                    case 27 -> "Date of Last Skip";
                    case 28 -> "Is Purchased";
                    case 29 -> "Audio File Extension";
                    case 30 -> "Is Checked";
                    case 31 -> "Copyright";
                    case 32 -> "Release Date";
                    case 33 -> "Purchased Track Identifier";
                    case 34 -> "Audio Matched Track Identifier";
                    case 35 -> "Tag Matched Track Identifier";
                    case 36 -> "Apple Music Track Identifier";
                    default -> "Unknown";
                };
                if(info.get(y).contains(type)){
                    if(y!=info.size()-1) {
                        if (strings.contains(i)) {
                            output.add(info.get(y).substring(info.get(y).indexOf(": \"") + 3, info.get(y).indexOf("\",")));
                        }
                        if (ints.contains(i) || booleans.contains(i)) {
                            output.add(info.get(y).substring(info.get(y).indexOf(": ") + 2, info.get(y).indexOf(",")));
                        }
                        if (i == 36) {
                            output.add(info.get(y).substring(info.get(y).indexOf(": ") + 2));
                        }
                        y++;
                    }else{
                        if (strings.contains(i)) {
                            output.add(info.get(y).substring(info.get(y).indexOf(": ") + 3));
                        }
                        if (ints.contains(i) || booleans.contains(i) || i ==36) {
                            output.add(info.get(y).substring(info.get(y).indexOf(": ") + 2));
                        }
                    }
                }else{
                    if(strings.contains(i)){
                        output.add("Unknown");
                    }
                    if(ints.contains(i) || i==36){
                        output.add("0");
                    }
                    if(booleans.contains(i)){
                        output.add("false");
                    }
                }
            }
            y=0;
            songInfoClass temporary = new songInfoClass(output.get(0), Integer.parseInt(output.get(1)), output.get(2),output.get(3),output.get(4),output.get(5),output.get(6),output.get(7).equals("true"),output.get(8),output.get(9),output.get(10),output.get(11),output.get(12),Integer.parseInt(output.get(13)),Integer.parseInt(output.get(14)),Integer.parseInt(output.get(15)),Integer.parseInt(output.get(16)),Integer.parseInt(output.get(17)),Integer.parseInt(output.get(18)),Integer.parseInt(output.get(19)),Integer.parseInt(output.get(20)),output.get(21),output.get(22),output.get(23),output.get(24),output.get(25),Integer.parseInt(output.get(26)),output.get(27),output.get(28).equals("true"),output.get(29),output.get(30).equals("true"),output.get(31),output.get(32),Integer.parseInt(output.get(33)),Integer.parseInt(output.get(34)),Integer.parseInt(output.get(35)),Integer.parseInt(output.get(36)));
            if(songInfo.size()==0)
                songInfo.add(temporary);
            else{
                for(songInfoClass m : songInfo){
                    if(m.getTitle().equalsIgnoreCase(temporary.getTitle()) && m.getArtist().equalsIgnoreCase(temporary.getArtist())){
                        checker = false;
                    }
                }
                if(checker)
                    songInfo.add(temporary);
            }

        }
        for(String s : csvInfo){
            List<String> info = new LinkedList<>(Arrays.asList(s.split("\",\"")));
            if(info.get(2).equalsIgnoreCase("Artist Name"))
                continue;
            List<String> output = new ArrayList<>();
            for(int i = 2; i < info.size(); i++){
                if(i==z[k]){
                if(!info.get(i).equalsIgnoreCase("")){
                    String temp = info.get(i);
                    switch (i){
                        case 2:
                        case 13:
                        case 20:
                        case 31:
                            output.add(temp);
                            break;
                        case 3:
                            if(temp.contains("iPhone") && temp.contains(" hwp")) {
                                //System.out.println(temp);
                                output.add(analyze.appleDecoder(temp.substring(temp.indexOf("iPhone"), temp.indexOf(" hwp"))));
                            }else
                                output.add("Windows Computer");
                            break;
                        case 7:
                        case 12:
                        case 16:
                            String[] cutUp = temp.split("_");
                            StringBuilder back = new StringBuilder();
                            for(String c : cutUp) {
                                back.append(c.charAt(0)).append(c.toLowerCase().substring(1)).append(" ");
                            }
                            output.add(back.toString());
                            break;
                        case 11:
                            temp = dateToString(temp,0);
                            output.add(temp);
                            break;
                        case 6:
                        case 15:
                        case 33:
                            temp = longToMMSSString(Long.parseLong(temp));
                            output.add(temp);
                            break;
                        case 21:
                            String temp2 = longToMMSSString(Long.parseLong(temp));
                            output.add(temp2);
                            output.add(temp);
                    }
                }else{
                    if(strs.contains(i))
                        output.add("Unknown");
                    if(integers.contains(i))
                        output.add("0:00");
                    if(i==20){
                        output.add("false");
                    }
                    if(i==21){
                        output.add("0:00");
                        output.add("0");
                    }
                }
                k++;
                }
            }
            if(onlyPLAYEND) {
                if(output.get(5).equalsIgnoreCase("Play End ")){
                    dataCreators.add(new dataCreator(output.get(0), output.get(1), output.get(2), output.get(3), output.get(4), output.get(5), output.get(6), output.get(7), output.get(8), output.get(9).equals("true"), output.get(10), output.get(11), output.get(12), output.get(13)));
            }}else{
                dataCreators.add(new dataCreator(output.get(0), output.get(1), output.get(2), output.get(3), output.get(4), output.get(5), output.get(6), output.get(7), output.get(8), output.get(9).equals("true"), output.get(10), output.get(11), output.get(12), output.get(13)));
            }k = 0;
        }
        for(dataCreator d : dataCreators){
            boolean check = false;
            for(songInfoClass p : songInfo){
                if(d.getArtistName().equalsIgnoreCase(p.getArtist()) && d.getSongName().equalsIgnoreCase(p.getTitle())){
                    returnValue.add(new dataObject(d.getArtistName(), d.getBuildVersion(), d.getEndReason(), d.getEventStart(), d.getEventType(), d.getFeatureName(), d.getMediaType(), d.getSongName(), d.getEndPosition(), d.getMediaDuration(), d.getStartPosition(), d.getPlayDuration(), p.getComposer(), p.getAlbum(), p.getAlbumArtist(), p.getGenre(), p.getDateAddedLibrary(), p.getLastPlayed(), p.getPurchaseDate(), p.getLastSkipDate(), p.getAudioFileExtension(), p.getReleaseDate(), p.getCopyright(), p.getYear(), p.getAlbumNumber(), p.getAlbumCount(), p.getBpm(), p.getPlayCount(), p.getSkipCount(), d.getPlayDurationInMills(), d.isOffline(), p.isCompilation()));
                    check = true;
                }
            }
            if(!check){
                returnValue.add(new dataObject(d.getArtistName(), d.getBuildVersion(), d.getEndReason(), d.getEventStart(), d.getEventType(), d.getFeatureName(), d.getMediaType(), d.getSongName(), d.getEndPosition(), d.getMediaDuration(), d.getStartPosition(), d.getPlayDuration(), "Unknown","Unknown","Unknown","Unknown","Unknown","Unknown","Unknown","Unknown","Unknown","Unknown","Unknown",0,0,0,0,0,0, d.getPlayDurationInMills(),false,false));
            }
        }
        return returnValue;
    }

    public static String readFileAsString(String filename){
        try {
            return new String(Files.readAllBytes(Paths.get(filename)));
        }catch (Exception e){
            return e.toString();
        }
    }

    public static ObservableList<frequencyList> firstLayerFrequencyMaker (ObservableList<dataObject> list, int id){
        Map<String, Integer> map = new HashMap<>();
        String temp = null;
        for(dataObject d : list){
            boolean check = false;
            switch (id) {
                case 0:
                if (!d.getArtist().equals("Unknown")) {
                    temp = d.getArtist();
                    check = true;
                }
                break;
                case 1:
                    if(!d.getTitle().equals("Unknown")){
                        temp = d.getTitle() + ", by " + d.getArtist();
                        check = true;
                    }
                    break;
                case 2:
                    if(!d.getGenre().equals("Unknown")){
                        temp = d.getGenre();
                        check = true;
                    }
                    break;
                case 3:
                    if(!d.getAlbum().equals("Unknown")){
                        if(!d.getAlbumArtist().equals("Unknown")){
                            temp = d.getAlbum() + ", by " + d.getAlbumArtist();
                        }else {
                            temp = d.getAlbum() + ", by " + d.getArtist();
                        }
                        check = true;
                    }
                    break;
                case 5:
                    if(!d.getEndReason().equalsIgnoreCase("Unknown")){
                        temp = d.getEndReason();
                        check = true;
                    }
                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + id);
            }
            if(check) {
                if (map.containsKey(temp))
                    map.put(temp, map.get(temp) + 1);
                else
                    map.put(temp, 1);
            }
        }
        return mapToObservableListFrequencyList(map);
    }

    public static ObservableList<playTimeObject> releaseDateAnalyzer(ObservableList<dataObject> list){
        String s;
        String date;
        Map<String, String> map = new HashMap<>();
        for(dataObject d : list) {
            if (!d.getReleaseDate().equalsIgnoreCase("Unknown")) {
                s = d.getTitle() + ", by " + d.getArtist();
                date = dateToString(d.getReleaseDate(),1);
                date = date.substring(0, date.indexOf(","));
                if (!map.containsKey(s)) {
                    map.put(s, date);
                }
            }
        }
        ObservableList<playTimeObject> pList = FXCollections.observableArrayList();
        ValueComparator<String,String> comparator = new ValueComparator<>(map);
        Map<String, String> sortedMap = new TreeMap<>(comparator);
        sortedMap.putAll(map);

        Set entries = sortedMap.entrySet();
        Iterator eI = entries.iterator();
        while(eI.hasNext()){
            Map.Entry mapping = (Map.Entry) eI.next();
            pList.add(new playTimeObject(mapping.getKey().toString(), mapping.getValue().toString()));
        }
        return pList;

    }

    public static ObservableList<playTimeObject> playTimeAnalyzer(ObservableList<dataObject> list, int id){
        Map<String, Long> map = new HashMap<>();
        String temp = null;
        long total = 0;
        switch(id) {
            case 6:
            for (dataObject d : list) {
                boolean check = false;
                if (Long.parseLong(d.getPlayDurationInMills()) > 0 && !d.getTitle().equalsIgnoreCase("Unknown")) {
                    total = Long.parseLong(d.getPlayDurationInMills());
                    temp = d.getTitle() + ", by " + d.getArtist();
                    check = true;
                }
                if (check) {
                    if (map.containsKey(temp)) {
                        map.put(temp, map.get(temp) + total);
                    } else {
                        map.put(temp, total);
                    }
                }
            }
            break;
            case 7:
                String song;
                long time;
                Map<String, Integer> tempMap = new HashMap<>();
                Map<String, Long> temporary = new HashMap<>();
                List<averageTimeObject> average = FXCollections.observableArrayList();
                for(dataObject d : list){
                    if(!d.getPlayDurationInMills().isEmpty() && !d.getTitle().equalsIgnoreCase("Unknown")){
                        song = d.getTitle() + ", by " + d.getArtist();
                        time = Long.parseLong(d.getPlayDurationInMills());
                        average.add(new averageTimeObject(song, time));
                    }
                }
                for(averageTimeObject a : average){
                    if(temporary.containsKey(a.getName())){
                        temporary.put(a.getName(), temporary.get(a.getName()) + a.getAverage());
                    }else{
                        temporary.put(a.getName(), a.getAverage());
                    }
                    if(tempMap.containsKey(a.getName())){
                        tempMap.put(a.getName(), tempMap.get(a.getName()) + 1);
                    }else{
                        tempMap.put(a.getName(),1);
                    }
                }
                Set temporarySet = temporary.entrySet();
                Iterator iterator = temporarySet.iterator();
                Set tempSet = tempMap.entrySet();
                Iterator tempIterator = tempSet.iterator();
                long aver = 0;
                while(iterator.hasNext()){
                    Map.Entry mapp = (Map.Entry) iterator.next();
                    Map.Entry mappp = (Map.Entry) tempIterator.next();
                    if(mapp.getKey().equals(mappp.getKey())){
                        aver = Long.parseLong(mapp.getValue().toString())/Long.parseLong(mappp.getValue().toString());
                    }
                        map.put(mapp.getKey().toString(), aver);
                }
                break;
        }
        ObservableList<playTimeObject> pList = FXCollections.observableArrayList();
        ValueComparator<String,Long> comparator = new ValueComparator<>(map);
        Map<String, Long> sortedMap = new TreeMap<>(comparator);
        sortedMap.putAll(map);

        Set entries = sortedMap.entrySet();
        Iterator eI = entries.iterator();
        while(eI.hasNext()){
            Map.Entry mapping = (Map.Entry) eI.next();
            pList.add(new playTimeObject(mapping.getKey().toString(), longToMMSSString(Long.parseLong(mapping.getValue().toString()))));
        }
        return pList;
    }

    public static ObservableList<frequencyList> secondLayerFrequencyMaker (ObservableList<dataObject> list, int id, String selection){
        Map<String, Integer> map = new HashMap<>();
        String temp = null;
        String album = null;
        if(id == homeController.ids.albums.getValue()){
            if(selection.contains(", by ")){
                album = selection.substring(0,selection.indexOf(", by "));
            }else{
                album = selection;
            }
        }
        for(dataObject d : list){
            boolean check = false;
            switch (id){
                case 0:
                    if(d.getArtist().equalsIgnoreCase(selection)) {
                        temp = d.getTitle();
                        check = true;
                    }
                    break;
                case 2:
                    if(d.getGenre().equalsIgnoreCase(selection)){
                        temp = d.getTitle() + ", by " + d.getArtist();
                        check = true;
                    }
                    break;
                case 3:
                    if(d.getAlbum().equalsIgnoreCase(album)){
                        temp = d.getTitle();
                        check = true;
                    }
                    break;

                default:
                    temp = "FAILED";
            }
            if(check){
                if(map.containsKey(temp))
                    map.put(temp, map.get(temp) + 1);
                else
                    map.put(temp,1);
            }
        }
        return mapToObservableListFrequencyList(map);
    }

    public static ObservableList<dataObject> selectedSongsTrackList(ObservableList<dataObject> list, String parse, int id){
        String name = parse.substring(0, parse.indexOf(", by "));
        String artist = parse.substring(parse.indexOf(", by ") + 5);
        ObservableList<dataObject> output = FXCollections.observableArrayList();

        for(dataObject d : list){
            switch(id){
                case 1:
                case 2:
                case 6:
                case 7:
                case 8:
                    if(d.getTitle().equalsIgnoreCase(name) && d.getArtist().equalsIgnoreCase(artist)){
                        output.add(d);
                    }
                    break;
            }
        }
        return output;
    }

    public static ObservableList<dataObject> selectedSongsTrackList(ObservableList<dataObject> list, String name, String artist, int id){
        ObservableList<dataObject> output = FXCollections.observableArrayList();
        for(dataObject d : list){
            switch(id) {
                case 0:
                    if (d.getTitle().equalsIgnoreCase(name) && d.getArtist().equalsIgnoreCase(artist)) {
                        output.add(d);
                    }
                break;
                case 3:
                    if(d.getTitle().equalsIgnoreCase(name) && d.getAlbum().equalsIgnoreCase(artist)){
                        output.add(d);
                    }
                    break;
            }
        }
        return output;
    }

    public static ObservableList<trackInfoColumn> trackInfoToColumn(ObservableList<dataObject> list, String name, String artist, int id){
        ObservableList<trackInfoColumn> output = FXCollections.observableArrayList();
        String type;
        List<Long> playDurations = new ArrayList<>();
        switch (id) {
            case 0 -> {
                for (dataObject d : list) {
                    if (d.getTitle().equalsIgnoreCase(name) && d.getArtist().equalsIgnoreCase(artist)) {
                        for (int i = 0; i < 19; i++) {
                            switch (i) {
                                case 0 -> {
                                    type = "Artist";
                                    if (!d.getArtist().equals("Unknown"))
                                        output.add(new trackInfoColumn(type, d.getArtist()));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 1 -> {
                                    type = "Title";
                                    if (!d.getTitle().equals("Unknown"))
                                        output.add(new trackInfoColumn(type, d.getTitle()));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 2 -> {
                                    type = "Media Duration";
                                    if (!d.getMediaDuration().equals("Unknown"))
                                        output.add(new trackInfoColumn(type, d.getMediaDuration()));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 3 -> {
                                    type = "Average Play Duration";
                                    output.add(new trackInfoColumn(type, "0:00"));
                                }
                                case 4 -> {
                                    type = "Composer";
                                    if (!d.getComposer().equals("Unknown"))
                                        output.add(new trackInfoColumn(type, d.getComposer()));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 5 -> {
                                    type = "Album";
                                    if (!d.getAlbum().equals("Unknown"))
                                        output.add(new trackInfoColumn(type, d.getAlbum()));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 6 -> {
                                    type = "Album Artist";
                                    if (!d.getAlbumArtist().equals("Unknown"))
                                        output.add(new trackInfoColumn(type, d.getAlbumArtist()));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 7 -> {
                                    type = "Genre";
                                    if (!d.getGenre().equals("Unknown"))
                                        output.add(new trackInfoColumn(type, d.getGenre()));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 8 -> {
                                    type = "Date Added To Library";
                                    if (!d.getdAL().equals("Unknown")) {
                                        String temp = dateToString(d.getdAL(),0);
                                        output.add(new trackInfoColumn(type, temp));
                                    } else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 9 -> {
                                    type = "Last Played";
                                    if (!d.getLastPlayed().equals("Unknown")) {
                                        String temp = dateToString(d.getLastPlayed(),0);
                                        output.add(new trackInfoColumn(type, temp));
                                    } else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 10 -> {
                                    type = "Last Skipped";
                                    if (!d.getLastSkip().equals("Unknown")) {
                                        String temp = dateToString(d.getLastSkip(),0);
                                        output.add(new trackInfoColumn(type, temp));
                                    } else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 11 -> {
                                    type = "Date of Purchase";
                                    if (!d.getPurchaseDate().equals("Unknown")) {
                                        String temp = dateToString(d.getPurchaseDate(),0);
                                        output.add(new trackInfoColumn(type, temp));
                                    } else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 12 -> {
                                    type = "Play Count";
                                    if (d.getPlayCount() != 0)
                                        output.add(new trackInfoColumn(type, String.valueOf(d.getPlayCount())));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 13 -> {
                                    type = "Skip Count";
                                    if (d.getSkipCount() != 0)
                                        output.add(new trackInfoColumn(type, String.valueOf(d.getSkipCount())));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 14 -> {
                                    type = "Release Date";
                                    if (!d.getReleaseDate().equals("Unknown")) {
                                        String temp = releaseDateFormatter(d.getReleaseDate());
                                        output.add(new trackInfoColumn(type, temp));
                                    } else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 15 -> {
                                    type = "Track Number On Album";
                                    if (d.getAlbumNumber() != 0)
                                        output.add(new trackInfoColumn(type, String.valueOf(d.getAlbumNumber())));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 16 -> {
                                    type = "Track Count On Album";
                                    if (d.getAlbumCount() != 0)
                                        output.add(new trackInfoColumn(type, String.valueOf(d.getAlbumCount())));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 17 -> {
                                    type = "Copyright";
                                    if (!d.getCopyright().equals("Unknown"))
                                        output.add(new trackInfoColumn(type, d.getCopyright()));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 18 -> {
                                    type = "BPM";
                                    if (d.getBpm() != 0)
                                        output.add(new trackInfoColumn(type, String.valueOf(d.getBpm())));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 19 -> {
                                    type = "Part of Compilation";
                                    output.add(new trackInfoColumn(type, String.valueOf(d.isCompilation())));
                                }
                                default -> type = "Unknown";
                            }
                        }
                        break;
                    }
                }
                for (dataObject d : list) {
                    if (d.getTitle().equalsIgnoreCase(name) && d.getArtist().equalsIgnoreCase(artist)) {
                        playDurations.add(Long.parseLong(d.getPlayDurationInMills()));
                    }
                }
                if (output.size() > 4) {
                    output.get(3).setOutput(longToMMSSString(averagePlay(playDurations)));
                }
            }
            case 3 -> {
                for (dataObject d : list) {
                    if (d.getTitle().equalsIgnoreCase(name) && d.getAlbum().equalsIgnoreCase(artist)) {
                        for (int i = 0; i < 19; i++) {
                            switch (i) {
                                case 0 -> {
                                    type = "Artist";
                                    if (!d.getArtist().equals("Unknown"))
                                        output.add(new trackInfoColumn(type, d.getArtist()));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 1 -> {
                                    type = "Title";
                                    if (!d.getTitle().equals("Unknown"))
                                        output.add(new trackInfoColumn(type, d.getTitle()));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 2 -> {
                                    type = "Media Duration";
                                    if (!d.getMediaDuration().equals("Unknown"))
                                        output.add(new trackInfoColumn(type, d.getMediaDuration()));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 3 -> {
                                    type = "Average Play Duration";
                                    output.add(new trackInfoColumn(type, "0:00"));
                                }
                                case 4 -> {
                                    type = "Composer";
                                    if (!d.getComposer().equals("Unknown"))
                                        output.add(new trackInfoColumn(type, d.getComposer()));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 5 -> {
                                    type = "Album";
                                    if (!d.getAlbum().equals("Unknown"))
                                        output.add(new trackInfoColumn(type, d.getAlbum()));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 6 -> {
                                    type = "Album Artist";
                                    if (!d.getAlbumArtist().equals("Unknown"))
                                        output.add(new trackInfoColumn(type, d.getAlbumArtist()));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 7 -> {
                                    type = "Genre";
                                    if (!d.getGenre().equals("Unknown"))
                                        output.add(new trackInfoColumn(type, d.getGenre()));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 8 -> {
                                    type = "Date Added To Library";
                                    if (!d.getdAL().equals("Unknown")) {
                                        String temp = dateToString(d.getdAL(),0);
                                        output.add(new trackInfoColumn(type, temp));
                                    } else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 9 -> {
                                    type = "Last Played";
                                    if (!d.getLastPlayed().equals("Unknown")) {
                                        String temp = dateToString(d.getLastPlayed(),0);
                                        output.add(new trackInfoColumn(type, temp));
                                    } else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 10 -> {
                                    type = "Last Skipped";
                                    if (!d.getLastSkip().equals("Unknown")) {
                                        String temp = dateToString(d.getLastSkip(),0);
                                        output.add(new trackInfoColumn(type, temp));
                                    } else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 11 -> {
                                    type = "Date of Purchase";
                                    if (!d.getPurchaseDate().equals("Unknown")) {
                                        String temp = dateToString(d.getPurchaseDate(),0);
                                        output.add(new trackInfoColumn(type, temp));
                                    } else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 12 -> {
                                    type = "Play Count";
                                    if (d.getPlayCount() != 0)
                                        output.add(new trackInfoColumn(type, String.valueOf(d.getPlayCount())));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 13 -> {
                                    type = "Skip Count";
                                    if (d.getSkipCount() != 0)
                                        output.add(new trackInfoColumn(type, String.valueOf(d.getSkipCount())));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 14 -> {
                                    type = "Release Date";
                                    if (!d.getReleaseDate().equals("Unknown")) {
                                        String temp = releaseDateFormatter(d.getReleaseDate());
                                        output.add(new trackInfoColumn(type, temp));
                                    } else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 15 -> {
                                    type = "Track Number On Album";
                                    if (d.getAlbumNumber() != 0)
                                        output.add(new trackInfoColumn(type, String.valueOf(d.getAlbumNumber())));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 16 -> {
                                    type = "Track Count On Album";
                                    if (d.getAlbumCount() != 0)
                                        output.add(new trackInfoColumn(type, String.valueOf(d.getAlbumCount())));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 17 -> {
                                    type = "Copyright";
                                    if (!d.getCopyright().equals("Unknown"))
                                        output.add(new trackInfoColumn(type, d.getCopyright()));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 18 -> {
                                    type = "BPM";
                                    if (d.getBpm() != 0)
                                        output.add(new trackInfoColumn(type, String.valueOf(d.getBpm())));
                                    else
                                        output.add(new trackInfoColumn(type, "Unknown"));
                                }
                                case 19 -> {
                                    type = "Part of Compilation";
                                    output.add(new trackInfoColumn(type, String.valueOf(d.isCompilation())));
                                }
                                default -> type = "Unknown";
                            }
                        }
                        break;
                    }
                }
                for (dataObject d : list) {
                    if (d.getTitle().equalsIgnoreCase(name) && d.getAlbum().equalsIgnoreCase(artist)) {
                        playDurations.add(Long.parseLong(d.getPlayDurationInMills()));
                    }
                }
                if (output.size() > 4) {
                    output.get(3).setOutput(longToMMSSString(averagePlay(playDurations)));
                }
            }
        }
        return output;
    }

    public static ObservableList<trackInfoColumn> trackInfoToColumn(ObservableList<dataObject> list, String parse){
        String name = parse.substring(0, parse.indexOf(", by "));
        String artist = parse.substring(parse.indexOf(", by ")+5);
        List<Long> playDurations = new ArrayList<>();

        ObservableList<trackInfoColumn> output = FXCollections.observableArrayList();
        String type;
        for (dataObject d : list) {
            if (d.getTitle().equalsIgnoreCase(name) && d.getArtist().equalsIgnoreCase(artist)) {
                for (int i = 0; i < 19; i++) {
                    switch (i) {
                        case 0 -> {
                            type = "Artist";
                            if (!d.getArtist().equals("Unknown"))
                                output.add(new trackInfoColumn(type, d.getArtist()));
                            else
                                output.add(new trackInfoColumn(type, "Unknown"));
                        }
                        case 1 -> {
                            type = "Title";
                            if (!d.getTitle().equals("Unknown"))
                                output.add(new trackInfoColumn(type, d.getTitle()));
                            else
                                output.add(new trackInfoColumn(type, "Unknown"));
                        }
                        case 2 -> {
                            type = "Media Duration";
                            if (!d.getMediaDuration().equals("Unknown"))
                                output.add(new trackInfoColumn(type, d.getMediaDuration()));
                            else
                                output.add(new trackInfoColumn(type, "Unknown"));
                        }
                        case 3 -> {
                            type = "Average Play Duration";
                            output.add(new trackInfoColumn(type, "0:00"));
                        }
                        case 4 -> {
                            type = "Composer";
                            if (!d.getComposer().equals("Unknown"))
                                output.add(new trackInfoColumn(type, d.getComposer()));
                            else
                                output.add(new trackInfoColumn(type, "Unknown"));
                        }
                        case 5 -> {
                            type = "Album";
                            if (!d.getAlbum().equals("Unknown"))
                                output.add(new trackInfoColumn(type, d.getAlbum()));
                            else
                                output.add(new trackInfoColumn(type, "Unknown"));
                        }
                        case 6 -> {
                            type = "Album Artist";
                            if (!d.getAlbumArtist().equals("Unknown"))
                                output.add(new trackInfoColumn(type, d.getAlbumArtist()));
                            else
                                output.add(new trackInfoColumn(type, "Unknown"));
                        }
                        case 7 -> {
                            type = "Genre";
                            if (!d.getGenre().equals("Unknown"))
                                output.add(new trackInfoColumn(type, d.getGenre()));
                            else
                                output.add(new trackInfoColumn(type, "Unknown"));
                        }
                        case 8 -> {
                            type = "Date Added To Library";
                            if (!d.getdAL().equals("Unknown")) {
                                String temp = dateToString(d.getdAL(), 0);
                                output.add(new trackInfoColumn(type, temp));
                            } else
                                output.add(new trackInfoColumn(type, "Unknown"));
                        }
                        case 9 -> {
                            type = "Last Played";
                            if (!d.getLastPlayed().equals("Unknown")) {
                                String temp = dateToString(d.getLastPlayed(),0);
                                output.add(new trackInfoColumn(type, temp));
                            } else
                                output.add(new trackInfoColumn(type, "Unknown"));
                        }
                        case 10 -> {
                            type = "Last Skipped";
                            if (!d.getLastSkip().equals("Unknown")) {
                                String temp = dateToString(d.getLastSkip(),0);
                                output.add(new trackInfoColumn(type, temp));
                            } else
                                output.add(new trackInfoColumn(type, "Unknown"));
                        }
                        case 11 -> {
                            type = "Date of Purchase";
                            if (!d.getPurchaseDate().equals("Unknown")) {
                                String temp = dateToString(d.getPurchaseDate(),0);
                                output.add(new trackInfoColumn(type, temp));
                            } else
                                output.add(new trackInfoColumn(type, "Unknown"));
                        }
                        case 12 -> {
                            type = "Play Count";
                            if (d.getPlayCount() != 0)
                                output.add(new trackInfoColumn(type, String.valueOf(d.getPlayCount())));
                            else
                                output.add(new trackInfoColumn(type, "Unknown"));
                        }
                        case 13 -> {
                            type = "Skip Count";
                            if (d.getSkipCount() != 0)
                                output.add(new trackInfoColumn(type, String.valueOf(d.getSkipCount())));
                            else
                                output.add(new trackInfoColumn(type, "Unknown"));
                        }
                        case 14 -> {
                            type = "Release Date";
                            if (!d.getReleaseDate().equals("Unknown")) {
                                String temp = releaseDateFormatter(d.getReleaseDate());
                                output.add(new trackInfoColumn(type, temp));
                            } else
                                output.add(new trackInfoColumn(type, "Unknown"));
                        }
                        case 15 -> {
                            type = "Track Number On Album";
                            if (d.getAlbumNumber() != 0)
                                output.add(new trackInfoColumn(type, String.valueOf(d.getAlbumNumber())));
                            else
                                output.add(new trackInfoColumn(type, "Unknown"));
                        }
                        case 16 -> {
                            type = "Track Count On Album";
                            if (d.getAlbumCount() != 0)
                                output.add(new trackInfoColumn(type, String.valueOf(d.getAlbumCount())));
                            else
                                output.add(new trackInfoColumn(type, "Unknown"));
                        }
                        case 17 -> {
                            type = "Copyright";
                            if (!d.getCopyright().equals("Unknown"))
                                output.add(new trackInfoColumn(type, d.getCopyright()));
                            else
                                output.add(new trackInfoColumn(type, "Unknown"));
                        }
                        case 18 -> {
                            type = "BPM";
                            if (d.getBpm() != 0)
                                output.add(new trackInfoColumn(type, String.valueOf(d.getBpm())));
                            else
                                output.add(new trackInfoColumn(type, "Unknown"));
                        }
                        case 19 -> {
                            type = "Part of Compilation";
                            output.add(new trackInfoColumn(type, String.valueOf(d.isCompilation())));
                        }
                        default -> type = "Unknown";
                    }
                }
                break;
            }
        }
        for (dataObject d : list) {
            if (d.getTitle().equalsIgnoreCase(name) && d.getArtist().equalsIgnoreCase(artist)) {
                playDurations.add(Long.parseLong(d.getPlayDurationInMills()));
            }
        }
        if (output.size() > 4) {
            output.get(3).setOutput(longToMMSSString(averagePlay(playDurations)));
        }
        return output;
    }

    public static String longToMMSSString(long average){
        Duration duration = Duration.ofMillis(average);
        long seconds = duration.getSeconds();
        long HH = seconds/3600;
        long MM = (seconds % 3600) / 60;
        long SS = seconds % 60;
        String HHtemp = String.valueOf(HH);
        String MMtemp = String.valueOf(MM);
        String SStemp = String.valueOf(SS);
        if(HH==0) {
            if (SS == 0)
                SStemp = "00";
            if (SS < 10)
                SStemp = "0" + SS;
            return MMtemp + ":" + SStemp;
        }else{
            if(MM == 0){
                MMtemp = "00";
            }
            if(MM<10){
                MMtemp = "0" + MM;
            }
            if (SS == 0)
                SStemp = "00";
            if (SS < 10)
                SStemp = "0" + SS;
            return HHtemp + ":" + MMtemp + ":" + SStemp;
        }
    }

    public static Long averagePlay(List<Long> list){
        long average = 0;
        if(list.size()!=0) {
            long total = 0;
            for (Long i : list) {
                total += i;
            }
            average = total / list.size();
        }
        return average;
    }

    public static String dateToString(String input, int version){
            String temp;
            LocalDateTime date = DateParserUtils.parseDateTime(input);
            int year = date.getYear();
            Month month = date.getMonth();
            int day = date.getDayOfMonth();
            String dayOfWeek = date.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.US);
            int hour = date.getHour();
            int minute = date.getMinute();
            int second = date.getSecond();
            String AMPM = "AM";
            String YYYY = String.valueOf(year);
            String MM = String.valueOf(month.getValue());
            String DD = String.valueOf(day);
            String HH = String.valueOf(hour);
            String mm = String.valueOf(minute);
            String ss = String.valueOf(second);
            if (day < 10)
                DD = "0" + day;
            if (hour >= 13) {
                HH = String.valueOf(hour - 12);
                AMPM = "PM";
            }
            if (hour == 12) {
                AMPM = "PM";
            }
            if (hour == 0) {
                HH = "12";
            }
            if (minute == 0)
                mm = "00";
            if (minute < 10)
                mm = "0" + minute;
            if (second == 0)
                ss = "00";
            if (second < 10)
                ss = "0" + second;
        temp = switch (version) {
            case 0 -> DD + "/" + MM + "/" + YYYY + " " + dayOfWeek + ", " + HH + ":" + mm + ":" + ss + " " + AMPM;
            case 1 -> YYYY + "/" + MM + "/" + DD + ", " + dayOfWeek;
            default -> "empty";
        };
        return temp;
    }

    public static String releaseDateFormatter(String input){
        LocalDateTime time = DateParserUtils.parseDateTime(input);
        String year = String.valueOf(time.getYear());
        String month = time.getMonth().getDisplayName(TextStyle.FULL, Locale.US);
        String day = String.valueOf(time.getDayOfMonth());
        String dayOfWeek = time.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.US);
        day = switch (time.getDayOfMonth()) {
            case 1, 21, 31 -> day + "st";
            case 2, 22 -> day + "nd";
            case 3, 23 -> day + "rd";
            default -> day + "th";
        };
        return dayOfWeek + ", " + month + " " + day + ", " + year;
    }

    public static ObservableList<PieChart.Data> pieChartDataMaker(ObservableList<dataObject> list, int id, int count){
        Map<String, Integer> map = new HashMap<>();
        String temp = null;
        ObservableList<PieChart.Data> data = FXCollections.observableArrayList();
        for(dataObject d : list){
            boolean check = false;
            switch (id){
                case 0:
                    if(!d.getArtist().equalsIgnoreCase("Unknown")){
                        temp = d.getArtist();
                        check = true;
                    }
                    break;
                case 1:
                    if(!d.getTitle().equalsIgnoreCase("Unknown")){
                        temp = d.getTitle()+ ", by " + d.getArtist();
                        check = true;
                    }
                    break;
                case 2:
                    if(!d.getGenre().equalsIgnoreCase("Unknown")){
                        temp = d.getGenre();
                        check = true;
                    }
                    break;
                case 3:
                    if(!d.getAlbum().equalsIgnoreCase("Unknown")){
                        if(!d.getAlbumArtist().equalsIgnoreCase("Unknown"))
                            temp = d.getAlbum() + ", by " + d.getAlbumArtist();
                        else
                            temp = d.getAlbum() + ", by " + d.getArtist();
                        check = true;
                    }
                    break;
                case 5:
                    if(!d.getEndReason().equalsIgnoreCase("Unknown")){
                        temp = d.getEndReason();
                        check = true;
                    }
                    break;
                default:
                    System.out.println("id is not matching any? id: " + id);
            }
            if(check){
                if(map.containsKey(temp))
                    map.put(temp,map.get(temp) +1);
                else
                    map.put(temp,1);
            }
        }
        ValueComparator<String,Integer> comparator = new ValueComparator<>(map);
        Map<String, Integer> sortedMap = new TreeMap<>(comparator);
        sortedMap.putAll(map);

        Set entries = sortedMap.entrySet();
        Iterator entriesIterator = entries.iterator();
        int x = 0;
        if(count < entries.size()){
            while(x < count){
                Map.Entry mapping = (Map.Entry) entriesIterator.next();
                if(id == 1 || id == 3) {
                    data.add(new PieChart.Data(mapping.getKey().toString().substring(0, mapping.getKey().toString().indexOf(", by ")), Integer.parseInt(mapping.getValue().toString())));
                }else{
                    data.add(new PieChart.Data(mapping.getKey().toString(), Integer.parseInt(mapping.getValue().toString())));
                }
                x++;
            }
        }else {
            while (entriesIterator.hasNext()) {
                Map.Entry mapping = (Map.Entry) entriesIterator.next();
                if(id == 1 || id == 3) {
                    data.add(new PieChart.Data(mapping.getKey().toString().substring(0, mapping.getKey().toString().indexOf(", by ")), Integer.parseInt(mapping.getValue().toString())));
                }else{
                    data.add(new PieChart.Data(mapping.getKey().toString(), Integer.parseInt(mapping.getValue().toString())));
                }
            }
        }
        return data;
    }

    public static ObservableList<PieChart.Data> pieChartDataFromPlayTimeObject(ObservableList<playTimeObject> list, int count){
        Map<String, Long> map = new HashMap<>();
        String temp;
        long time;
        ObservableList<PieChart.Data> data = FXCollections.observableArrayList();
        for(playTimeObject p : list){
            if(!p.getName().equalsIgnoreCase("Unknown")){
                temp = p.getName();
                time = timeToLong(p.getPlayTime());
                if(map.containsKey(temp)){
                    map.put(temp, map.get(temp) + time);
                }else{
                    map.put(temp, time);
                    //System.out.println(time);
                }
            }
        }
        ValueComparator<String,Long> comparator = new ValueComparator<>(map);
        Map<String, Long> sortedMap = new TreeMap<>(comparator);
        sortedMap.putAll(map);

        Set entries = sortedMap.entrySet();
        Iterator entriesIterator = entries.iterator();
        int x = 0;
        if(count < entries.size()){
            while(x < count){
                Map.Entry mapping = (Map.Entry) entriesIterator.next();
                //System.out.println(mapping.getValue().toString());
                    data.add(new PieChart.Data(mapping.getKey().toString().substring(0, mapping.getKey().toString().indexOf(", by ")), Long.parseLong(mapping.getValue().toString())));
                x++;
            }
        }else {
            while (entriesIterator.hasNext()) {
                Map.Entry mapping = (Map.Entry) entriesIterator.next();
                    data.add(new PieChart.Data(mapping.getKey().toString().substring(0, mapping.getKey().toString().indexOf(", by ")), Integer.parseInt(mapping.getValue().toString())));
            }
        }
        return data;

    }

    public static long timeToLong(String input){
        //System.out.println(input);
        String time[] = input.split(":");
        String HH = "0";
        String MM = "0";
        String SS = "0";
        long hour;
        long minute;
        long second;
        if(time.length == 3){
            HH = time[0];
            MM = time[1];
            SS = time[2];
            //System.out.println(HH);
            //System.out.println(MM);
            //System.out.println(SS);
        }
        if(time.length == 2){
            MM = time[0];
            SS = time[1];
            //System.out.println(MM);
           // System.out.println(SS);
        }
        hour = Long.parseLong(HH) * 3600;
        //System.out.println("hour: " + hour);
        minute = Long.parseLong(MM) * 60;
        //System.out.println("minute: " + minute);
        second = Long.parseLong(SS);
        //System.out.println("second: " +second);
        return hour + minute + second;
    }

    public static ObservableList<XYChart.Data> dayFrequency(ObservableList<dataObject> list, int id){
        Map<DayOfWeek, Integer> map = new HashMap<>();
        DayOfWeek temp;
        ObservableList<XYChart.Data> fList = FXCollections.observableArrayList();
        switch(id) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            for (dataObject d : list) {
                if (!d.getEventStart().equalsIgnoreCase("Unknown")) {
                    temp = DateParserUtils.parseDateTime(d.getEventStart()).getDayOfWeek();
                    if (map.containsKey(temp)) {
                        map.put(temp, map.get(temp) + 1);
                    } else {
                        map.put(temp, 1);
                    }
                }
            }

            break;
            case 9:
                for(dataObject d  : list){
                    if(!d.getReleaseDate().equalsIgnoreCase("Unknown")){
                        temp = DateParserUtils.parseDateTime(d.getReleaseDate()).getDayOfWeek();
                        if(map.containsKey(temp)){
                            map.put(temp, map.get(temp) + 1);
                        }else{
                            map.put(temp, 1);
                        }
                    }
                }
                break;
        }
        if (map.size() < 7) {
            for (int i = 1; i <= 7; i++) {
                if (!map.containsKey(DayOfWeek.of(i))) {
                    map.put(DayOfWeek.of(i), 0);
                }
            }
        }
        Map<DayOfWeek, Integer> sortedMap = new TreeMap<>(map);
        Set entries = sortedMap.entrySet();
        Iterator eI = entries.iterator();
        while(eI.hasNext()){
            Map.Entry mapping = (Map.Entry) eI.next();
            fList.add(new XYChart.Data(mapping.getKey().toString(), Integer.parseInt(mapping.getValue().toString())));
        }
        return fList;
    }

    public static ObservableList<XYChart.Data> dayFrequencyFromPlayTimeObject(ObservableList<playTimeObject> list){
        Map<DayOfWeek, Integer> map = new HashMap<>();
        DayOfWeek temp;
        ObservableList<XYChart.Data> fList = FXCollections.observableArrayList();
        for(playTimeObject d  : list){
            if(!d.getName().equalsIgnoreCase("Unknown")){
                temp = DateParserUtils.parseDateTime(d.getPlayTime()).getDayOfWeek();
                if(map.containsKey(temp)){
                    map.put(temp, map.get(temp) + 1);
                }else{
                    map.put(temp, 1);
                }
            }
        }
        if (map.size() < 7) {
            for (int i = 1; i <= 7; i++) {
                if (!map.containsKey(DayOfWeek.of(i))) {
                    map.put(DayOfWeek.of(i), 0);
                }
            }
        }
        Map<DayOfWeek, Integer> sortedMap = new TreeMap<>(map);
        Set entries = sortedMap.entrySet();
        Iterator eI = entries.iterator();
        while(eI.hasNext()){
            Map.Entry mapping = (Map.Entry) eI.next();
            fList.add(new XYChart.Data(mapping.getKey().toString(), Integer.parseInt(mapping.getValue().toString())));
        }
        return fList;
    }

    public static ObservableList<XYChart.Data> yearFrequency(ObservableList<playTimeObject> list){
        ObservableList<XYChart.Data> output = FXCollections.observableArrayList();
        int year;
        Map<String, Integer> map = new HashMap<>();
        for(playTimeObject d : list){
            if(!d.getName().equalsIgnoreCase("Unknown")){
                year = DateParserUtils.parseDateTime(d.getPlayTime()).getYear();
                String y = String.valueOf(Math.floor(Math.floorDiv(year, 10))*10);
                y = y.substring(0, y.indexOf("."));
                if(map.containsKey(y)){
                    map.put(y, map.get(y) + 1);
                }else{
                    map.put(y, 1);
                }
            }
        }

        Map<String, Integer> sortedMap = new TreeMap<>(map);

        Set entries = sortedMap.entrySet();
        Iterator entriesIterator = entries.iterator();
        while(entriesIterator.hasNext()){
            Map.Entry mapping = (Map.Entry) entriesIterator.next();
            output.add(new XYChart.Data(mapping.getKey().toString(),Integer.parseInt(mapping.getValue().toString())));
        }
       return output;
    }

    public static ObservableList<XYChart.Data> monthFrequencyFromPlayTimeObject(ObservableList<playTimeObject> list){
        Map<Month, Integer> map = new HashMap<>();
        Month temp;
        ObservableList<XYChart.Data> fList = FXCollections.observableArrayList();
        for(playTimeObject d : list){
            if(!d.getName().equalsIgnoreCase("Unknown")){
                temp = DateParserUtils.parseDateTime(d.getPlayTime()).getMonth();
                if(map.containsKey(temp)){
                    map.put(temp, map.get(temp) + 1);
                }else{
                    map.put(temp, 1);
                }
            }
        }
        if (map.size() < 12) {
            for (int i = 1; i <= 12; i++) {
                if (!map.containsKey(Month.of(i)))
                    map.put(Month.of(i), 0);
            }
        }


        Map<Month, Integer> sortedMap = new TreeMap<>(map);

        Set entries = sortedMap.entrySet();
        Iterator entriesIterator = entries.iterator();
        while(entriesIterator.hasNext()){
            Map.Entry mapping = (Map.Entry) entriesIterator.next();
            fList.add(new XYChart.Data(mapping.getKey().toString(),Integer.parseInt(mapping.getValue().toString())));
        }
        return fList;
    }

    public static ObservableList<XYChart.Data> monthFrequency(ObservableList<dataObject> list, int id){
        Map<Month, Integer> map = new HashMap<>();
        Month temp;
        ObservableList<XYChart.Data> fList = FXCollections.observableArrayList();
        
        switch(id) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            for (dataObject d : list) {
                if (!d.getEventStart().equals("Unknown")) {
                    temp = DateParserUtils.parseDateTime(d.getEventStart()).getMonth();
                    if (map.containsKey(temp)) {
                        map.put(temp, map.get(temp) + 1);
                    } else {
                        map.put(temp, 1);
                    }
                }
            }
            break;
            case 9:
                for(dataObject d : list){
                    if(!d.getReleaseDate().equalsIgnoreCase("Unknown")){
                        temp = DateParserUtils.parseDateTime(d.getReleaseDate()).getMonth();
                        if(map.containsKey(temp)){
                            map.put(temp, map.get(temp) + 1);
                        }else{
                            map.put(temp, 1);
                        }
                    }
                }
                break;
        }
        if (map.size() < 12) {
            for (int i = 1; i <= 12; i++) {
                if (!map.containsKey(Month.of(i)))
                    map.put(Month.of(i), 0);
            }
        }


        Map<Month, Integer> sortedMap = new TreeMap<>(map);

        Set entries = sortedMap.entrySet();
        Iterator entriesIterator = entries.iterator();
        while(entriesIterator.hasNext()){
            Map.Entry mapping = (Map.Entry) entriesIterator.next();
            fList.add(new XYChart.Data(mapping.getKey().toString(),Integer.parseInt(mapping.getValue().toString())));
        }
        return fList;
    }

    public static ObservableList<XYChart.Series> yearAndMonth(ObservableList<dataObject> list){
        List<Integer> years = new ArrayList<>();
        ObservableList<XYChart.Series> output = FXCollections.observableArrayList();
        int year;
        Month month;
        for(dataObject d : list) {
            if (!d.getEventStart().equalsIgnoreCase("Unknown")) {
                year = DateParserUtils.parseDateTime(d.getEventStart()).getYear();
                if (!years.contains(year)) {
                    years.add(year);
                }
            }
        }
        Collections.sort(years);
        for(Integer y : years) {
            Map<Month, Integer> map = new HashMap<>();
            ObservableList<XYChart.Data> monthsList = FXCollections.observableArrayList();
            for (dataObject d : list) {
                if(!d.getEventStart().equalsIgnoreCase("Unknown")){
                    year = DateParserUtils.parseDateTime(d.getEventStart()).getYear();
                    if (!d.getEventStart().equalsIgnoreCase("Unknown") && y.equals(year)) {
                        month = DateParserUtils.parseDateTime(d.getEventStart()).getMonth();
                        if(y==2021 && month.getValue()==12) {
                            //System.out.println(d.getTitle() + ": " + d.getEventStart());
                            //System.out.println(month);
                        }
                        if (map.containsKey(month)) {
                            map.put(month, map.get(month) + 1);
                        } else {
                            map.put(month, 1);
                    }
                }
             }
            }
            if(map.size() < 12){
                for(int i = 1; i <= 12; i++){
                    if(!map.containsKey(Month.of(i)))
                        map.put(Month.of(i), 0);
                }
            }

            Map<Month, Integer> sortedMap = new TreeMap<>(map);

            Set entries = sortedMap.entrySet();
            Iterator eI = entries.iterator();
            while(eI.hasNext()){
                Map.Entry mapping = (Map.Entry) eI.next();
                monthsList.add(new XYChart.Data(mapping.getKey().toString(), Integer.parseInt(mapping.getValue().toString())));
            }
            XYChart.Series series = new XYChart.Series<>();
            series.setName(String.valueOf(y));
            series.setData(monthsList);

            output.add(series);
        }
        return output;
    }

    public static ObservableList<XYChart.Data> timeFrequency(ObservableList<dataObject> list){
        Map<Integer, Integer> map = new HashMap<>();
        int temp;
        int i;
        ObservableList<XYChart.Data> fList = FXCollections.observableArrayList();
        for(dataObject d : list){
            if(!d.getEventStart().equals("Unknown")){
                    temp = DateParserUtils.parseDateTime(d.getEventStart()).getHour();
                if(map.containsKey(temp)){
                    map.put(temp, map.get(temp) + 1);
                }else{
                    map.put(temp,1);
                }
            }
        }
        if (map.size() < 24) {
            for (int j = 0; j < 24; j++) {
                if (!map.containsKey(j))
                    map.put(j, 0);
            }
        }

        Map<Integer, Integer> sortedMap = new TreeMap<>(map);

        Set entries = sortedMap.entrySet();
        Iterator entriesIterator = entries.iterator();
        String out;
        while(entriesIterator.hasNext()){
            Map.Entry mapping = (Map.Entry) entriesIterator.next();
            i = Integer.parseInt(mapping.getKey().toString());
            if(0<i && i<12){
                    out = i + ":00 AM";
                }else if(i>=13){
                    out = (i-12) + ":00 PM";
                }else if (i==0){
                    out = "12:00 AM";
                }else{
                out = "12:00 PM";
            }
            fList.add(new XYChart.Data(out,Integer.parseInt(mapping.getValue().toString())));
        }
        return fList;
    }

    public static String appleDecoder(String name){
        switch (name){
            case "i386":
            case "x86_64":
            case "arm64":
                return "iPhone Simulator";
            case "iPhone1,1":
                return "iPhone";
            case "iPhone1,2":
                return "iPhone 3G";
            case "iPhone2,1":
                return "iPhone 3GS";
            case "iPhone3,1":
                return "iPhone 4";
            case "iPhone3,2":
                return "iPhone 4 GSM Rev A";
            case "iPhone3,3":
                return "iPhone 4 CDMA";
            case "iPhone4,1":
                return "iPhone 4S";
            case "iPhone5,1":
                return "iPhone 5 (GSM)";
            case "iPhone5,2":
                return "iPhone 5 (GSM+CDMA)";
            case "iPhone5,3":
                return "iPhone 5C (GSM)";
            case "iPhone5,4":
                return "iPhone 5C (Global)";
            case "iPhone6,1":
                return "iPhone 5S (GSM)";
            case "iPhone6,2":
                return "iPhone 5S (Global)";
            case "iPhone7,1":
                return "iPhone 6 Plus";
            case "iPhone7,2":
                return "iPhone 6";
            case "iPhone8,1":
                return "iPhone 6s";
            case "iPhone8,2":
                return "iPhone 6s Plus";
            case "iPhone8,4":
                return "iPhone SE (GSM)";
            case "iPhone9,1":
            case "iPhone9,3":
                return "iPhone 7";
            case "iPhone9,2":
            case "iPhone9,4":
                return "iPhone 7 Plus";
            case "iPhone10,1":
            case "iPhone10,4":
                return "iPhone 8";
            case "iPhone10,2":
            case "iPhone10,5":
                return "iPhone 8 Plus";
            case "iPhone10,3":
                return "iPhone X Global";
            case "iPhone10,6":
                return "iPhone X GSM";
            case "iPhone11,2":
                return "iPhone XS";
            case "iPhone11,4":
                return "iPhone XS Max";
            case "iPhone11,6":
                return "iPhone XS Max Global";
            case "iPhone11,8":
                return "iPhone XR";
            case "iPhone12,1":
                return "iPhone 11";
            case "iPhone12,3":
                return "iPhone 11 Pro";
            case "iPhone12,5":
                return "iPhone 11 Pro Max";
            case "iPhone12,8":
                return "iPhone SE 2nd Gen";
            case "iPhone13,1":
                return "iPhone 12 Mini";
            case "iPhone13,2":
                return "iPhone 12";
            case "iPhone13,3":
                return "iPhone 12 Pro";
            case "iPhone13,4":
                return "iPhone 12 Pro Max";
            case "iPhone14,2":
                return "iPhone 13 Pro";
            case "iPhone14,3":
                return "iPhone 13 Pro Max";
            case "iPhone14,4":
                return "iPhone 13 Mini";
            case "iPhone14,5":
                return "iPhone 13";
            case "iPhone14,6":
                return "iPhone SE 3rd Gen";
            default:
                return "Unknown";
        }
    }

    public static ObservableList<frequencyList> mapToObservableListFrequencyList(Map map) {
        ObservableList<frequencyList> fList = FXCollections.observableArrayList();
        ValueComparator<String, String> comparator = new ValueComparator<>(map);
        Map<String, String> sortedMap = new TreeMap<>(comparator);
        sortedMap.putAll(map);

        Set entries = sortedMap.entrySet();
        Iterator entriesIterator = entries.iterator();
        while(entriesIterator.hasNext()){
            Map.Entry mapping = (Map.Entry) entriesIterator.next();
            try {
                fList.add(new frequencyList(mapping.getKey().toString(), NumberFormat.getNumberInstance().format(Integer.parseInt(mapping.getValue().toString()))));
            }catch (Exception e){
                e.printStackTrace();
            }
            }
        return fList;
    }

    public static frequencyList headerInfoFromAlbum(ObservableList<dataObject> info, String name, String album){
        String temp = "Unknown";
        for(dataObject d : info){
            if(d.getAlbum().equalsIgnoreCase(album) && d.getTitle().equalsIgnoreCase(name))
                temp = d.getArtist();
        }
        return new frequencyList(temp, "0");
    }

    public static frequencyList illusionOfChoice(ObservableList<frequencyList> data){
        double totalWeight = 0.0;

        int max = 10;
        int min = 1;
        int range = max - min + 1;
        int random = (int)(Math.random() * range) + min;
        int ind = 0;
try {
    if (random != 1) {
        for (frequencyList l : data) {
            totalWeight += (1f / NumberFormat.getNumberInstance(Locale.US).parse(l.getFrequency()).intValue());
        }

        for (double r = Math.random() * totalWeight; ind < data.size(); ind++) {
            r -= (1f / NumberFormat.getNumberInstance(Locale.US).parse(data.get(ind).getFrequency()).intValue());
            if (r <= 0.0) {
                break;
            }
        }
    } else {
        for (frequencyList l : data) {
            totalWeight += NumberFormat.getNumberInstance(Locale.US).parse(l.getFrequency()).intValue();
        }
        for (double r = Math.random() * totalWeight; ind < data.size(); ind++) {
            r -= NumberFormat.getNumberInstance(Locale.US).parse(data.get(ind).getFrequency()).intValue();
            if (r <= 0.0) {
                break;
            }
        }
    }
}catch (Exception e){
    e.printStackTrace();
}

        return data.get(ind);
    }

    public static String encodeValue(String value) throws UnsupportedEncodingException {
        return URLEncoder.encode(value, StandardCharsets.UTF_8.toString());
    }
}
class ValueComparator<K, V extends Comparable<V>> implements Comparator<K>{
    Map<K,V> map;

    public ValueComparator(Map<K,V> base) {this.map = base;}

    @Override
    public int compare(K o1, K o2){
        int freqCompare = map.get(o2).compareTo(map.get(o1));
        int valueCompare = o1.toString().compareTo(o2.toString());

        if(freqCompare==0){
            return valueCompare;
        }else{
            return freqCompare;
        }
    }
}
