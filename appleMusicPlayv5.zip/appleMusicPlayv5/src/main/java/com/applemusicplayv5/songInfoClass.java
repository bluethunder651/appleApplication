package com.applemusicplayv5;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class songInfoClass {
    private SimpleStringProperty contentType, title, artist, sortTrackName, sortArtistName, composer, album, sortAlbumName, albumArtist, genre, grouping, dateAddedLibrary, dateAddedCloud, lastModified, lastPlayed, purchaseDate, lastSkipDate, audioFileExtension, releaseDate, copyright;
    private SimpleIntegerProperty trackID, year, albumNumber, albumCount, discNumber, discCount, bpm, duration, playCount, skipCount, purchasedID, matchedTrackID, tagMatchedTrackID, appleMusicTrackID;
    private SimpleBooleanProperty compilation, purchased, checked;

    public songInfoClass(String contentType, int trackID, String title, String sortTrackName, String artist, String sortArtistName, String composer, boolean compilation, String album, String sortAlbumName, String albumArtist, String genre, String grouping, int year, int albumNumber, int albumCount, int discNumber, int discCount, int bpm, int duration, int playCount, String dateAddedLibrary, String dateAddedCloud, String lastModified, String lastPlayed, String purchaseDate, int skipCount, String lastSkipDate, boolean purchased, String audioFileExtension, boolean checked, String copyright, String releaseDate, int purchasedID, int matchedTrackID, int tagMatchedTrackID, int appleMusicTrackID) {
        this.contentType = new SimpleStringProperty(contentType);
        this.title = new SimpleStringProperty(title);
        this.artist = new SimpleStringProperty(artist);
        this.sortArtistName = new SimpleStringProperty(sortArtistName);
        this.sortTrackName = new SimpleStringProperty(sortTrackName);
        this.copyright = new SimpleStringProperty(copyright);
        this.grouping = new SimpleStringProperty(grouping);
        this.sortAlbumName = new SimpleStringProperty(sortAlbumName);
        this.composer = new SimpleStringProperty(composer);
        this.album = new SimpleStringProperty(album);
        this.albumArtist = new SimpleStringProperty(albumArtist);
        this.genre = new SimpleStringProperty(genre);
        this.dateAddedLibrary = new SimpleStringProperty(dateAddedLibrary);
        this.dateAddedCloud = new SimpleStringProperty(dateAddedCloud);
        this.lastModified = new SimpleStringProperty(lastModified);
        this.lastPlayed = new SimpleStringProperty(lastPlayed);
        this.purchaseDate = new SimpleStringProperty(purchaseDate);
        this.lastSkipDate = new SimpleStringProperty(lastSkipDate);
        this.audioFileExtension = new SimpleStringProperty(audioFileExtension);
        this.releaseDate = new SimpleStringProperty(releaseDate);
        this.trackID = new SimpleIntegerProperty(trackID);
        this.year = new SimpleIntegerProperty(year);
        this.bpm = new SimpleIntegerProperty(bpm);
        this.albumNumber = new SimpleIntegerProperty(albumNumber);
        this.albumCount = new SimpleIntegerProperty(albumCount);
        this.discNumber = new SimpleIntegerProperty(discNumber);
        this.discCount = new SimpleIntegerProperty(discCount);
        this.duration = new SimpleIntegerProperty(duration);
        this.playCount = new SimpleIntegerProperty(playCount);
        this.skipCount = new SimpleIntegerProperty(skipCount);
        this.purchasedID = new SimpleIntegerProperty(purchasedID);
        this.matchedTrackID = new SimpleIntegerProperty(matchedTrackID);
        this.tagMatchedTrackID = new SimpleIntegerProperty(tagMatchedTrackID);
        this.appleMusicTrackID = new SimpleIntegerProperty(appleMusicTrackID);
        this.compilation = new SimpleBooleanProperty(compilation);
        this.purchased = new SimpleBooleanProperty(purchased);
        this.checked = new SimpleBooleanProperty(checked);
    }

    public String getSortTrackName() {
        return sortTrackName.get();
    }

    public SimpleStringProperty sortTrackNameProperty() {
        return sortTrackName;
    }

    public void setSortTrackName(String sortTrackName) {
        this.sortTrackName.set(sortTrackName);
    }

    public String getSortArtistName() {
        return sortArtistName.get();
    }

    public SimpleStringProperty sortArtistNameProperty() {
        return sortArtistName;
    }

    public void setSortArtistName(String sortArtistName) {
        this.sortArtistName.set(sortArtistName);
    }

    public String getSortAlbumName() {
        return sortAlbumName.get();
    }

    public SimpleStringProperty sortAlbumNameProperty() {
        return sortAlbumName;
    }

    public void setSortAlbumName(String sortAlbumName) {
        this.sortAlbumName.set(sortAlbumName);
    }

    public String getGrouping() {
        return grouping.get();
    }

    public SimpleStringProperty groupingProperty() {
        return grouping;
    }

    public void setGrouping(String grouping) {
        this.grouping.set(grouping);
    }

    public String getCopyright() {
        return copyright.get();
    }

    public SimpleStringProperty copyrightProperty() {
        return copyright;
    }

    public void setCopyright(String copyright) {
        this.copyright.set(copyright);
    }

    public int getBpm() {
        return bpm.get();
    }

    public SimpleIntegerProperty bpmProperty() {
        return bpm;
    }

    public void setBpm(int bpm) {
        this.bpm.set(bpm);
    }

    public String getComposer() {
        return composer.get();
    }

    public SimpleStringProperty composerProperty() {
        return composer;
    }

    public void setComposer(String composer) {
        this.composer.set(composer);
    }

    public String getContentType() {
        return contentType.get();
    }

    public SimpleStringProperty contentTypeProperty() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType.set(contentType);
    }

    public String getTitle() {
        return title.get();
    }

    public SimpleStringProperty titleProperty() {
        return title;
    }

    public void setTitle(String title) {
        this.title.set(title);
    }

    public String getArtist() {
        return artist.get();
    }

    public SimpleStringProperty artistProperty() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist.set(artist);
    }

    public String getAlbum() {
        return album.get();
    }

    public SimpleStringProperty albumProperty() {
        return album;
    }

    public void setAlbum(String album) {
        this.album.set(album);
    }

    public String getAlbumArtist() {
        return albumArtist.get();
    }

    public SimpleStringProperty albumArtistProperty() {
        return albumArtist;
    }

    public void setAlbumArtist(String albumArtist) {
        this.albumArtist.set(albumArtist);
    }

    public String getGenre() {
        return genre.get();
    }

    public SimpleStringProperty genreProperty() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre.set(genre);
    }

    public String getDateAddedLibrary() {
        return dateAddedLibrary.get();
    }

    public SimpleStringProperty dateAddedLibraryProperty() {
        return dateAddedLibrary;
    }

    public void setDateAddedLibrary(String dateAddedLibrary) {
        this.dateAddedLibrary.set(dateAddedLibrary);
    }

    public String getDateAddedCloud() {
        return dateAddedCloud.get();
    }

    public SimpleStringProperty dateAddedCloudProperty() {
        return dateAddedCloud;
    }

    public void setDateAddedCloud(String dateAddedCloud) {
        this.dateAddedCloud.set(dateAddedCloud);
    }

    public String getLastModified() {
        return lastModified.get();
    }

    public SimpleStringProperty lastModifiedProperty() {
        return lastModified;
    }

    public void setLastModified(String lastModified) {
        this.lastModified.set(lastModified);
    }

    public String getLastPlayed() {
        return lastPlayed.get();
    }

    public SimpleStringProperty lastPlayedProperty() {
        return lastPlayed;
    }

    public void setLastPlayed(String lastPlayed) {
        this.lastPlayed.set(lastPlayed);
    }

    public String getPurchaseDate() {
        return purchaseDate.get();
    }

    public SimpleStringProperty purchaseDateProperty() {
        return purchaseDate;
    }

    public void setPurchaseDate(String purchaseDate) {
        this.purchaseDate.set(purchaseDate);
    }

    public String getLastSkipDate() {
        return lastSkipDate.get();
    }

    public SimpleStringProperty lastSkipDateProperty() {
        return lastSkipDate;
    }

    public void setLastSkipDate(String lastSkipDate) {
        this.lastSkipDate.set(lastSkipDate);
    }

    public String getAudioFileExtension() {
        return audioFileExtension.get();
    }

    public SimpleStringProperty audioFileExtensionProperty() {
        return audioFileExtension;
    }

    public void setAudioFileExtension(String audioFileExtension) {
        this.audioFileExtension.set(audioFileExtension);
    }

    public String getReleaseDate() {
        return releaseDate.get();
    }

    public SimpleStringProperty releaseDateProperty() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate.set(releaseDate);
    }

    public int getTrackID() {
        return trackID.get();
    }

    public SimpleIntegerProperty trackIDProperty() {
        return trackID;
    }

    public void setTrackID(int trackID) {
        this.trackID.set(trackID);
    }

    public int getYear() {
        return year.get();
    }

    public SimpleIntegerProperty yearProperty() {
        return year;
    }

    public void setYear(int year) {
        this.year.set(year);
    }

    public int getAlbumNumber() {
        return albumNumber.get();
    }

    public SimpleIntegerProperty albumNumberProperty() {
        return albumNumber;
    }

    public void setAlbumNumber(int albumNumber) {
        this.albumNumber.set(albumNumber);
    }

    public int getAlbumCount() {
        return albumCount.get();
    }

    public SimpleIntegerProperty albumCountProperty() {
        return albumCount;
    }

    public void setAlbumCount(int albumCount) {
        this.albumCount.set(albumCount);
    }

    public int getDiscNumber() {
        return discNumber.get();
    }

    public SimpleIntegerProperty discNumberProperty() {
        return discNumber;
    }

    public void setDiscNumber(int discNumber) {
        this.discNumber.set(discNumber);
    }

    public int getDiscCount() {
        return discCount.get();
    }

    public SimpleIntegerProperty discCountProperty() {
        return discCount;
    }

    public void setDiscCount(int discCount) {
        this.discCount.set(discCount);
    }

    public int getDuration() {
        return duration.get();
    }

    public SimpleIntegerProperty durationProperty() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration.set(duration);
    }

    public int getPlayCount() {
        return playCount.get();
    }

    public SimpleIntegerProperty playCountProperty() {
        return playCount;
    }

    public void setPlayCount(int playCount) {
        this.playCount.set(playCount);
    }

    public int getSkipCount() {
        return skipCount.get();
    }

    public SimpleIntegerProperty skipCountProperty() {
        return skipCount;
    }

    public void setSkipCount(int skipCount) {
        this.skipCount.set(skipCount);
    }

    public int getPurchasedID() {
        return purchasedID.get();
    }

    public SimpleIntegerProperty purchasedIDProperty() {
        return purchasedID;
    }

    public void setPurchasedID(int purchasedID) {
        this.purchasedID.set(purchasedID);
    }

    public int getMatchedTrackID() {
        return matchedTrackID.get();
    }

    public SimpleIntegerProperty matchedTrackIDProperty() {
        return matchedTrackID;
    }

    public void setMatchedTrackID(int matchedTrackID) {
        this.matchedTrackID.set(matchedTrackID);
    }

    public int getTagMatchedTrackID() {
        return tagMatchedTrackID.get();
    }

    public SimpleIntegerProperty tagMatchedTrackIDProperty() {
        return tagMatchedTrackID;
    }

    public void setTagMatchedTrackID(int tagMatchedTrackID) {
        this.tagMatchedTrackID.set(tagMatchedTrackID);
    }

    public int getAppleMusicTrackID() {
        return appleMusicTrackID.get();
    }

    public SimpleIntegerProperty appleMusicTrackIDProperty() {
        return appleMusicTrackID;
    }

    public void setAppleMusicTrackID(int appleMusicTrackID) {
        this.appleMusicTrackID.set(appleMusicTrackID);
    }

    public boolean isCompilation() {
        return compilation.get();
    }

    public SimpleBooleanProperty compilationProperty() {
        return compilation;
    }

    public void setCompilation(boolean compilation) {
        this.compilation.set(compilation);
    }

    public boolean isPurchased() {
        return purchased.get();
    }

    public SimpleBooleanProperty purchasedProperty() {
        return purchased;
    }

    public void setPurchased(boolean purchased) {
        this.purchased.set(purchased);
    }

    public boolean isChecked() {
        return checked.get();
    }

    public SimpleBooleanProperty checkedProperty() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked.set(checked);
    }
}
