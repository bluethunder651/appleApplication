package com.applemusicplayv5;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class dataObject {

    private final SimpleStringProperty artist, buildVersion, endReason, eventStart, eventType, feature, mediaType, title, endPos, mediaDuration, startPos, playDuration, composer, album, albumArtist, genre, dAL, lastPlayed, purchaseDate, lastSkip, aFE, releaseDate, copyright, playDurationInMills;
    private final SimpleIntegerProperty year, albumNumber, albumCount, bpm, playCount, skipCount;
    private final SimpleBooleanProperty offline, compilation;

    public dataObject(String artist, String buildVersion, String endReason, String eventStart, String eventType, String feature, String mediaType, String title, String endPos, String mediaDuration, String startPos, String playDuration, String composer, String album, String albumArtist, String genre, String dAL, String lastPlayed, String purchaseDate, String lastSkip, String aFE, String releaseDate, String copyright, int year, int albumNumber, int albumCount, int bpm, int playCount, int skipCount, String playDurationInMills, boolean offline, boolean compilation) {
        this.artist = new SimpleStringProperty(artist);
        this.buildVersion = new SimpleStringProperty(buildVersion);
        this.endReason = new SimpleStringProperty(endReason);
        this.eventStart = new SimpleStringProperty(eventStart);
        this.eventType = new SimpleStringProperty(eventType);
        this.feature = new SimpleStringProperty(feature);
        this.mediaType = new SimpleStringProperty(mediaType);
        this.title = new SimpleStringProperty(title);
        this.endPos = new SimpleStringProperty(endPos);
        this.mediaDuration = new SimpleStringProperty(mediaDuration);
        this.startPos = new SimpleStringProperty(startPos);
        this.playDuration = new SimpleStringProperty(playDuration);
        this.composer = new SimpleStringProperty(composer);
        this.album = new SimpleStringProperty(album);
        this.albumArtist = new SimpleStringProperty(albumArtist);
        this.genre = new SimpleStringProperty(genre);
        this.dAL = new SimpleStringProperty(dAL);
        this.lastPlayed = new SimpleStringProperty(lastPlayed);
        this.purchaseDate = new SimpleStringProperty(purchaseDate);
        this.lastSkip = new SimpleStringProperty(lastSkip);
        this.aFE = new SimpleStringProperty(aFE);
        this.releaseDate = new SimpleStringProperty(releaseDate);
        this.copyright = new SimpleStringProperty(copyright);
        this.year = new SimpleIntegerProperty(year);
        this.albumNumber = new SimpleIntegerProperty(albumNumber);
        this.albumCount = new SimpleIntegerProperty(albumCount);
        this.bpm = new SimpleIntegerProperty(bpm);
        this.playCount = new SimpleIntegerProperty(playCount);
        this.skipCount = new SimpleIntegerProperty(skipCount);
        this.offline = new SimpleBooleanProperty(offline);
        this.compilation = new SimpleBooleanProperty(compilation);
        this.playDurationInMills = new SimpleStringProperty(playDurationInMills);
    }

    public String getPlayDurationInMills() {
        return playDurationInMills.get();
    }

    public SimpleStringProperty playDurationInMillsProperty() {
        return playDurationInMills;
    }

    public void setPlayDurationInMills(String playDurationInMills) {
        this.playDurationInMills.set(playDurationInMills);
    }

    public String getArtist() {
        return artist.get();
    }

    public SimpleStringProperty artistProperty() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist.set(artist);
    }

    public String getBuildVersion() {
        return buildVersion.get();
    }

    public SimpleStringProperty buildVersionProperty() {
        return buildVersion;
    }

    public void setBuildVersion(String buildVersion) {
        this.buildVersion.set(buildVersion);
    }

    public String getEndReason() {
        return endReason.get();
    }

    public SimpleStringProperty endReasonProperty() {
        return endReason;
    }

    public void setEndReason(String endReason) {
        this.endReason.set(endReason);
    }

    public String getEventStart() {
        return eventStart.get();
    }

    public SimpleStringProperty eventStartProperty() {
        return eventStart;
    }

    public void setEventStart(String eventStart) {
        this.eventStart.set(eventStart);
    }

    public String getEventType() {
        return eventType.get();
    }

    public SimpleStringProperty eventTypeProperty() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType.set(eventType);
    }

    public String getFeature() {
        return feature.get();
    }

    public SimpleStringProperty featureProperty() {
        return feature;
    }

    public void setFeature(String feature) {
        this.feature.set(feature);
    }

    public String getMediaType() {
        return mediaType.get();
    }

    public SimpleStringProperty mediaTypeProperty() {
        return mediaType;
    }

    public void setMediaType(String mediaType) {
        this.mediaType.set(mediaType);
    }

    public String getTitle() {
        return title.get();
    }

    public SimpleStringProperty titleProperty() {
        return title;
    }

    public void setTitle(String title) {
        this.title.set(title);
    }

    public String getEndPos() {
        return endPos.get();
    }

    public SimpleStringProperty endPosProperty() {
        return endPos;
    }

    public void setEndPos(String endPos) {
        this.endPos.set(endPos);
    }

    public String getMediaDuration() {
        return mediaDuration.get();
    }

    public SimpleStringProperty mediaDurationProperty() {
        return mediaDuration;
    }

    public void setMediaDuration(String mediaDuration) {
        this.mediaDuration.set(mediaDuration);
    }

    public String getStartPos() {
        return startPos.get();
    }

    public SimpleStringProperty startPosProperty() {
        return startPos;
    }

    public void setStartPos(String startPos) {
        this.startPos.set(startPos);
    }

    public String getPlayDuration() {
        return playDuration.get();
    }

    public SimpleStringProperty playDurationProperty() {
        return playDuration;
    }

    public void setPlayDuration(String playDuration) {
        this.playDuration.set(playDuration);
    }

    public String getComposer() {
        return composer.get();
    }

    public SimpleStringProperty composerProperty() {
        return composer;
    }

    public void setComposer(String composer) {
        this.composer.set(composer);
    }

    public String getAlbum() {
        return album.get();
    }

    public SimpleStringProperty albumProperty() {
        return album;
    }

    public void setAlbum(String album) {
        this.album.set(album);
    }

    public String getAlbumArtist() {
        return albumArtist.get();
    }

    public SimpleStringProperty albumArtistProperty() {
        return albumArtist;
    }

    public void setAlbumArtist(String albumArtist) {
        this.albumArtist.set(albumArtist);
    }

    public String getGenre() {
        return genre.get();
    }

    public SimpleStringProperty genreProperty() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre.set(genre);
    }

    public String getdAL() {
        return dAL.get();
    }

    public SimpleStringProperty dALProperty() {
        return dAL;
    }

    public void setdAL(String dAL) {
        this.dAL.set(dAL);
    }

    public String getLastPlayed() {
        return lastPlayed.get();
    }

    public SimpleStringProperty lastPlayedProperty() {
        return lastPlayed;
    }

    public void setLastPlayed(String lastPlayed) {
        this.lastPlayed.set(lastPlayed);
    }

    public String getPurchaseDate() {
        return purchaseDate.get();
    }

    public SimpleStringProperty purchaseDateProperty() {
        return purchaseDate;
    }

    public void setPurchaseDate(String purchaseDate) {
        this.purchaseDate.set(purchaseDate);
    }

    public String getLastSkip() {
        return lastSkip.get();
    }

    public SimpleStringProperty lastSkipProperty() {
        return lastSkip;
    }

    public void setLastSkip(String lastSkip) {
        this.lastSkip.set(lastSkip);
    }

    public String getaFE() {
        return aFE.get();
    }

    public SimpleStringProperty aFEProperty() {
        return aFE;
    }

    public void setaFE(String aFE) {
        this.aFE.set(aFE);
    }

    public String getReleaseDate() {
        return releaseDate.get();
    }

    public SimpleStringProperty releaseDateProperty() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate.set(releaseDate);
    }

    public String getCopyright() {
        return copyright.get();
    }

    public SimpleStringProperty copyrightProperty() {
        return copyright;
    }

    public void setCopyright(String copyright) {
        this.copyright.set(copyright);
    }

    public int getYear() {
        return year.get();
    }

    public SimpleIntegerProperty yearProperty() {
        return year;
    }

    public void setYear(int year) {
        this.year.set(year);
    }

    public int getAlbumNumber() {
        return albumNumber.get();
    }

    public SimpleIntegerProperty albumNumberProperty() {
        return albumNumber;
    }

    public void setAlbumNumber(int albumNumber) {
        this.albumNumber.set(albumNumber);
    }

    public int getAlbumCount() {
        return albumCount.get();
    }

    public SimpleIntegerProperty albumCountProperty() {
        return albumCount;
    }

    public void setAlbumCount(int albumCount) {
        this.albumCount.set(albumCount);
    }

    public int getBpm() {
        return bpm.get();
    }

    public SimpleIntegerProperty bpmProperty() {
        return bpm;
    }

    public void setBpm(int bpm) {
        this.bpm.set(bpm);
    }

    public int getPlayCount() {
        return playCount.get();
    }

    public SimpleIntegerProperty playCountProperty() {
        return playCount;
    }

    public void setPlayCount(int playCount) {
        this.playCount.set(playCount);
    }

    public int getSkipCount() {
        return skipCount.get();
    }

    public SimpleIntegerProperty skipCountProperty() {
        return skipCount;
    }

    public void setSkipCount(int skipCount) {
        this.skipCount.set(skipCount);
    }

    public boolean isOffline() {
        return offline.get();
    }

    public SimpleBooleanProperty offlineProperty() {
        return offline;
    }

    public void setOffline(boolean offline) {
        this.offline.set(offline);
    }

    public boolean isCompilation() {
        return compilation.get();
    }

    public SimpleBooleanProperty compilationProperty() {
        return compilation;
    }

    public void setCompilation(boolean compilation) {
        this.compilation.set(compilation);
    }
}
