package com.applemusicplayv5;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;

import java.awt.*;
import java.io.IOException;
import java.net.URI;

public class fullTrackInfoController {

    @FXML private TableView<dataObject> fullTable;
    @FXML private TableColumn<dataObject,String> buildVersion;
    @FXML private TableColumn<dataObject,String> endReason;
    @FXML private TableColumn<dataObject,String> eventStart;
    @FXML private TableColumn<dataObject,String> eventType;
    @FXML private TableColumn<dataObject,String> featureName;
    @FXML private TableColumn<dataObject,String> mediaType;
    @FXML private TableColumn<dataObject,Boolean> offline;
    @FXML private TableColumn<dataObject,Integer> endPosition;
    @FXML private TableColumn<dataObject,Integer> mediaDuration;
    @FXML private TableColumn<dataObject,Integer> startPosition;
    @FXML private TableColumn<dataObject,Integer> playDuration;

    @FXML private TableView<trackInfoColumn> songInfo;
    @FXML private TableColumn<songInfoClass, String> field;
    @FXML private TableColumn<trackInfoColumn, String> output;

    @FXML private VBox vBox;
    @FXML private Button back;
    @FXML private Button home;
    @FXML private Label header;
    @FXML private Button openAppleMusic;
    @FXML private Button openYoutube;
    @FXML private Button openSpotify;
    @FXML private Button randomRedo;
    @FXML private Button barCharts;

    private dataModel model;
    private String toEncodeURL;
    private String toEncodeSpotify;

    public void init(dataModel model, int id){
        if(this.model!=null){
            throw new IllegalStateException("model no null");
        }
        this.model = model;

        buildVersion.setCellValueFactory(new PropertyValueFactory<>("buildVersion"));
        endReason.setCellValueFactory(new PropertyValueFactory<>("endReason"));
        eventStart.setCellValueFactory(new PropertyValueFactory<>("eventStart"));
        eventType.setCellValueFactory(new PropertyValueFactory<>("eventType"));
        featureName.setCellValueFactory(new PropertyValueFactory<>("feature"));
        mediaType.setCellValueFactory(new PropertyValueFactory<>("mediaType"));
        offline.setCellValueFactory(new PropertyValueFactory<>("offline"));
        endPosition.setCellValueFactory(new PropertyValueFactory<>("endPos"));
        mediaDuration.setCellValueFactory(new PropertyValueFactory<>("mediaDuration"));
        startPosition.setCellValueFactory(new PropertyValueFactory<>("startPos"));
        playDuration.setCellValueFactory(new PropertyValueFactory<>("playDuration"));

        field.setCellValueFactory(new PropertyValueFactory<>("field"));
        output.setCellValueFactory(new PropertyValueFactory<>("output"));

        fullTable.prefHeightProperty().bind(vBox.heightProperty());

        randomRedo.setVisible(false);
        String name;
        String artist;
        switch (id){
            case 0:
                toEncodeURL = model.getCurrentSecondLayerFrequencyData().getName() + ", by " + model.getCurrentFirstLayerFrequencyArtistData().getName();
                toEncodeSpotify = model.getCurrentSecondLayerFrequencyData().getName() + " " + model.getCurrentFirstLayerFrequencyArtistData().getName();
                field.setText(model.getCurrentSecondLayerFrequencyData().getName());
                output.setText(model.getCurrentFirstLayerFrequencyArtistData().getName());
                break;
            case 1:
            case 4:
                toEncodeURL = model.getCurrentFirstLayerFrequencyArtistData().getName();
                name =  model.getCurrentFirstLayerFrequencyArtistData().getName().substring(0, model.getCurrentFirstLayerFrequencyArtistData().getName().indexOf(", by "));
                artist = model.getCurrentFirstLayerFrequencyArtistData().getName().substring(model.getCurrentFirstLayerFrequencyArtistData().getName().indexOf(", by ")+5);
                toEncodeSpotify = name + " " + artist;
                field.setText(name);
                output.setText(artist);
                break;
            case 2:
                toEncodeURL = model.getCurrentSongFromGenreFrequencyData().getName();
                name = model.getCurrentSongFromGenreFrequencyData().getName().substring(0, model.getCurrentSongFromGenreFrequencyData().getName().indexOf(", by "));
                artist = model.getCurrentSongFromGenreFrequencyData().getName().substring(model.getCurrentSongFromGenreFrequencyData().getName().indexOf(", by ")+5);
                toEncodeSpotify = name + " " + artist;
                field.setText(name);
                output.setText(artist);
                break;
            case 3:
                toEncodeURL = model.getCurrentSongFromAlbumFrequencyData().getName() + ", by " + model.getHeaderFromAlbum().getName();
                toEncodeSpotify = model.getCurrentSongFromAlbumFrequencyData().getName() + " " + model.getHeaderFromAlbum().getName();
                field.setText(model.getCurrentSongFromAlbumFrequencyData().getName());
                output.setText(model.getHeaderFromAlbum().getName());
                break;
            case 6:
                toEncodeURL = model.getCurrentTotalPlayTimeList().getName();
                name = model.getCurrentTotalPlayTimeList().getName().substring(0,model.getCurrentTotalPlayTimeList().getName().indexOf(", by "));
                artist = model.getCurrentTotalPlayTimeList().getName().substring(model.getCurrentTotalPlayTimeList().getName().indexOf(", by ") + 5);
                toEncodeSpotify = name + " " +artist;
                field.setText(model.getCurrentTotalPlayTimeList().getName());
                output.setText(model.getCurrentTotalPlayTimeList().getPlayTime());
                break;
            case 7:
                toEncodeURL = model.getCurrentAveragePlayTimeListData().getName();
                name = model.getCurrentAveragePlayTimeListData().getName().substring(0,model.getCurrentAveragePlayTimeListData().getName().indexOf(", by "));
                artist = model.getCurrentAveragePlayTimeListData().getName().substring(model.getCurrentAveragePlayTimeListData().getName().indexOf(", by ") + 5);
                toEncodeSpotify = name + " " +artist;
                field.setText(model.getCurrentAveragePlayTimeListData().getName());
                output.setText(model.getCurrentAveragePlayTimeListData().getPlayTime());
                break;
            case 8:
                toEncodeURL = model.getCurrentReleaseDateListData().getName();
                name = model.getCurrentReleaseDateListData().getName().substring(0, model.getCurrentReleaseDateListData().getName().indexOf(", by "));
                artist = model.getCurrentReleaseDateListData().getName().substring(model.getCurrentReleaseDateListData().getName().indexOf(", by ") + 5);
                toEncodeSpotify = name + " " + artist;
                field.setText(name);
                output.setText(artist);
                break;
        }
        model.setHeader(toEncodeURL);
        header.setText(model.getHeader());
        if(id==4)
            randomRedo.setVisible(true);


        songInfo.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        field.setMaxWidth(1f*Integer.MAX_VALUE*40);
        output.setMaxWidth(1f*Integer.MAX_VALUE*60);

        fullTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        buildVersion.setMaxWidth(1f*Integer.MAX_VALUE*5);
        endReason.setMaxWidth(1f*Integer.MAX_VALUE*10);
        eventStart.setMaxWidth(1f*Integer.MAX_VALUE*10);
        eventType.setMaxWidth(1f*Integer.MAX_VALUE*5);
        featureName.setMaxWidth(1f*Integer.MAX_VALUE*5);
        mediaType.setMaxWidth(1f*Integer.MAX_VALUE*4);
        offline.setMaxWidth(1f*Integer.MAX_VALUE*2.5);
        endPosition.setMaxWidth(1f*Integer.MAX_VALUE*4);
        mediaDuration.setMaxWidth(1f*Integer.MAX_VALUE*4);
        startPosition.setMaxWidth(1f*Integer.MAX_VALUE*2.5);
        playDuration.setMaxWidth(1f*Integer.MAX_VALUE*4);

        songInfo.sort();
        songInfo.setItems(model.getTrackInfoColumnList());
        songInfo.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            model.setCurrentTrackInfoColumnData(newSelection);
        });

        fullTable.getSelectionModel().clearSelection();
        fullTable.setItems(model.getSelectedSongsTrackList());
        fullTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            model.setCurrentSelectedSongTrackData(newSelection);
        });


        randomRedo.setOnAction(actionEvent -> {
            try {
                redoButton(model);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        back.setOnAction(actionEvent -> {
            try {
                backbutton(model, id);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        home.setOnAction(actionEvent -> {
            try {
                homeButton(model);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        openAppleMusic.setOnAction(actionEvent -> {
            appleMusicButton();
        });
        openYoutube.setOnAction(actionEvent -> {
            youtubeButton();
        });
        openSpotify.setOnAction(actionEvent -> {
            spotifyButton();
        });
        barCharts.setOnAction(actionEvent -> {
            try {
                barCharts(model, id);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

    }

    public void backbutton(dataModel model, int id) throws IOException {
        switch (id){
            case 0:
            case 1:
            case 2:
            case 3:
            case 6:
            case 7:
            case 8:
                FXMLLoader lists = new FXMLLoader(getClass().getResource("listWithPieChart.fxml"));
                lists.load();
                listWithPieChartController list = lists.getController();
                list.init(model, id, 1);
                if(fullTable.getScene()!=null)
                    fullTable.getScene().setRoot(lists.getRoot());
                break;
            case 4:
                FXMLLoader home = new FXMLLoader(getClass().getResource("home.fxml"));
                home.load();
                homeController homeController = home.getController();
                homeController.init(model);
                fullTable.getScene().setRoot(home.getRoot());
                break;
        }
    }
    public void homeButton(dataModel model) throws IOException {
        FXMLLoader home = new FXMLLoader(getClass().getResource("home.fxml"));
        home.load();
        homeController homeController = home.getController();
        homeController.init(model);
        fullTable.getScene().setRoot(home.getRoot());
    }
    public void redoButton(dataModel model) throws IOException{
        frequencyList choice = analyze.illusionOfChoice(model.getFirstLayerSongFrequencyList());
        model.setCurrentFirstLayerArtistFrequencyData(choice);
        model.loadSelectedSongTrackListFromSongMenu();
        model.loadTrackInfoColumnListFromSongMenu();
        FXMLLoader full = new FXMLLoader(getClass().getResource("fullTrackInfo.fxml"));
        full.load();
        fullTrackInfoController fullTrackInfoController = full.getController();
        fullTrackInfoController.init(model, 4);
        if(fullTable.getScene()!=null){
            fullTable.getScene().setRoot(full.getRoot());
        }
    }
    public void appleMusicButton() {
        try {
            Desktop desktop = Desktop.getDesktop();
            String url;
            url = analyze.encodeValue(toEncodeURL);
            URI oURL = new URI("https://music.apple.com/us/search?term=" + url);
            desktop.browse(oURL);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void youtubeButton(){
        try{
            Desktop desktop = Desktop.getDesktop();
            String url;
            url = analyze.encodeValue(toEncodeURL);
            URI oURL = new URI("https://www.youtube.com/results?search_query=" + url);
            desktop.browse(oURL);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void spotifyButton(){
        try{
            Desktop desktop = Desktop.getDesktop();
            String url;
            url = analyze.encodeValue(toEncodeSpotify).replace("+","%20");
            URI oURL = new URI("https://open.spotify.com/search/" + url);
            desktop.browse(oURL);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void barCharts(dataModel model, int id) throws IOException {
        FXMLLoader bar = new FXMLLoader(getClass().getResource("dateBarCharts.fxml"));
        bar.load();
        dateBarChartsController dateBarChartsController = bar.getController();
        model.loadDayFromFrequencyList(id);
        model.loadMonthFromSongFrequencyList(id);
        model.loadYearFromSongAndMonthFrequencyList();
        model.loadTimeFromSongFrequencyList();
        if(id!=4) {
            dateBarChartsController.init(model, id);
        }else{
            dateBarChartsController.init(model, id, true);
        }
        if(fullTable.getScene()!=null){
            fullTable.getScene().setRoot(bar.getRoot());
        }
    }



}
