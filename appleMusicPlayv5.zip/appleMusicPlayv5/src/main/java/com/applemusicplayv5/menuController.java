package com.applemusicplayv5;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.stage.Popup;
import javafx.stage.Window;

import java.awt.*;
import java.io.File;
import java.io.IOException;

public class menuController {

    @FXML private Button start;
    @FXML private Button csvFile;
    @FXML private Button trackJson;
    @FXML private Label warningLabel;
    @FXML private CheckBox onlyPlayEnd;

    public void init() {

        FileChooser fileChooser = new FileChooser();

        dataModel dataModel = new dataModel();

        Popup warning = new Popup();



        warning.getContent().add(warningLabel);
        warningLabel.setMinSize(80,50);

        start.setOnAction(actionEvent -> {
            dataModel.setOnlyPlayEnd(onlyPlayEnd.isSelected());
            if(dataModel.getCsvFile()==null)
                dataModel.setCsvFile( "E:\\Actual documents\\Apple Media Services information\\Apple Media Services information\\Apple_Media_Services\\Apple_Media_Services\\Apple Music Activity\\Apple Music Play Activity.csv");
            if(dataModel.getTrackJson()==null)
                dataModel.setTrackJson("E:\\Actual documents\\Apple Media Services information\\Apple Media Services information\\Apple_Media_Services\\Apple_Media_Services\\Apple Music Activity\\Apple Music Library Tracks.json\\Apple Music Library Tracks.json");
                try {
                    if(warning.isShowing())
                        warning.hide();
                    dataModel.loadBeginningData();
                    goHome(dataModel);
                } catch (Exception e) {
                    e.printStackTrace();
                }
        });


        csvFile.setOnAction(actionEvent -> {
            if(warning.isShowing())
                warning.hide();
            File csvPath = fileChooser.showOpenDialog(start.getScene().getWindow());
            if(csvPath != null && csvPath.getAbsolutePath().endsWith(".csv")){
                dataModel.setCsvFile(csvPath.getAbsolutePath());
            }else{
                dataModel.setCsvFile( "E:\\Actual documents\\Apple Media Services information\\Apple Media Services information\\Apple_Media_Services\\Apple_Media_Services\\Apple Music Activity\\Apple Music Play Activity.csv");
            }
        });
        trackJson.setOnAction(actionEvent -> {
            if(warning.isShowing())
                warning.hide();
            File jsonPath = fileChooser.showOpenDialog(start.getScene().getWindow());
            if(jsonPath != null && jsonPath.getAbsolutePath().endsWith(".json")){
                dataModel.setTrackJson(jsonPath.getAbsolutePath());
            }else{
                dataModel.setTrackJson("E:\\Actual documents\\Apple Media Services information\\Apple Media Services information\\Apple_Media_Services\\Apple_Media_Services\\Apple Music Activity\\Apple Music Library Tracks.json\\Apple Music Library Tracks.json");
            }
        });


    }

    public void goHome(dataModel model) throws IOException {
        FXMLLoader homeLoader = new FXMLLoader(getClass().getResource("home.fxml"));
        homeLoader.load();
        homeController homeController = homeLoader.getController();
        homeController.init(model);
        start.getScene().setRoot(homeLoader.getRoot());
    }


}
