package com.applemusicplayv5;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class frequencyList {

    private SimpleStringProperty name, frequency;

    public frequencyList(String name, String frequency) {
        this.name = new SimpleStringProperty(name);
        this.frequency = new SimpleStringProperty(frequency);
    }

    public String getName() {
        return name.get();
    }

    public SimpleStringProperty nameProperty() {
        return name;
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public String getFrequency() {
        return frequency.get();
    }

    public SimpleStringProperty frequencyProperty() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency.set(frequency);
    }
}
