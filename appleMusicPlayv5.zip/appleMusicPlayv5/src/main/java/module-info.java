module com.applemusicplayv5 {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.json;
    requires json.simple;
    requires com.google.gson;
    requires java.desktop;
    requires dateparser;


    opens com.applemusicplayv5 to javafx.fxml;
    exports com.applemusicplayv5;
}